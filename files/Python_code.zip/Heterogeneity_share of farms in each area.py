# -*- coding: utf-8 -*-
"""
Created on Sun Dec 10 09:41:59 2023

@author: Yanan
"""
'''
===============================================================================
*************Determine how PR changes dairy farmer's optimal strategies********
  Based on optimal strategies solved by the model, we can determine the farmer's 
  optimal strategies by inserting true values of beta,l1,l2,l3,b,d and v. 
  It is the best if these values for each specific farms are availiable. However,
  there are too much missing data. Given data limitaitons, we divide farms by 
  their characteristics into groups and use medians within group to set paramter
  values of l1,l2,l3 and b for each farm. The beta is assumed to be constant across 
  group at level of 0.35. We use therapeutic use cost and veterinary service cost 
  reported by a farm to estimate individual-specific d and v. In summary, l1,l2,
  l3 and b are estimated on the level of farm groups, beta is assumed to be 
  constant at level of 0.35, and d and v are estimated at individual farm level.  
  
  After determine optimal strategy for each farms, we can caculate the shares of
  farms that have the same optimal strategies. 
===============================================================================
'''
import pandas as pd
'''
1. From the dairy survey data described in our paper, we can extrapolate values 
   for beta,l1,l2,l3, and b.
   We list values used for different farm groups. To determine optimal strategies
   for a certain farm group, we need to make value list for all other farm groups
   inactive and so add remark "#" at the beginning of lines for all other farm groups.
   
   
   The current code is used to determine the optimal strategies for high 
   productivity dairy farms.
'''

#beta,l1,l2,l3,b=0.35,90,150,800,28.5  #small farm size
#beta,l1,l2,l3,b=0.35,95,150,820,40  #medium farm size
#beta,l1,l2,l3,b=0.35,110,150,565,25  #large farm size
#beta,l1,l2,l3,b=0.35,70,150,575,25 #MI state
#beta,l1,l2,l3,b=0.35,92.5,150,627.5, 25 #MN state
#beta,l1,l2,l3,b=0.35,105,150,761, 30 #WI state
#beta,l1,l2,l3,b=0.35,60,150,510,20 # low productivity
#beta,l1,l2,l3,b=0.35,107,150,791.5,30 #medium productivity
beta,l1,l2,l3,b=0.35,120,150,650,30 #high productivity

'''
2. Import farm-individual data of therapeutic use and veterinary service costs
'''
var = pd.read_excel("obs.xlsx")
d_small = list(var['d_small']) # variable d_small is self-test cost for small farms
v_small = list(var['v_small']) # variable v_small is veterinary service cost for small farms
d_medium = list(var['d_medium']) # variable d_medium is self-test cost for medium farms
v_medium = list(var['v_medium']) # variable v_small is veterinary service cost for small farms
d_large = list(var['d_large']) # variable d_small is self-test cost for small farms
v_large = list(var['v_large']) # variable v_small is veterinary service cost for small farms
d_MI = list(var['d_MI']) # variable d_small is self-test cost for small farms
v_MI = list(var['v_MI']) # variable v_small is veterinary service cost for small farms
d_MN = list(var['d_MN']) # variable d_small is self-test cost for small farms
v_MN = list(var['v_MN']) # variable v_small is veterinary service cost for small farms
d_WI = list(var['d_WI']) # variable d_small is self-test cost for small farms
v_WI = list(var['v_WI']) # variable v_small is veterinary service cost for small farms
d_low = list(var['d_low']) # variable d_small is self-test cost for small farms
v_low = list(var['v_low']) # variable v_small is veterinary service cost for small farms
d_med = list(var['d_med']) # variable d_small is self-test cost for small farms
v_med = list(var['v_med']) # variable v_small is veterinary service cost for small farms
d_high = list(var['d_high']) # variable d_small is self-test cost for small farms
v_high = list(var['v_high']) # variable v_small is veterinary service cost for small farms

df=pd.DataFrame([[d_small,v_small,d_medium,v_medium,d_large,v_large,d_MI,v_MI,\
               d_MN,v_MN,d_WI,v_WI,d_low,v_low,d_med,v_med,d_high,v_high]],
             columns=['d_small','v_small','d_medium','v_medium','d_large',\
                      'v_large','d_MI','v_MI','d_MN','v_MN','d_WI','v_WI',\
                      'd_low','v_low','d_med','v_med','d_high','v_high'])
'''
3. Determine the unregulated and PR-regulated optimal strategies 
'''
# Determine the unregulated optimal strategies. The code is copy from d-v_without regulations.py
def color_nopr(d,v):
    if ((b<=l2-l1 and v<=l3-l2 and d<=(1-beta)*(l3+b-l2-v) and d<=beta*v) \
        or (b>l2-l1 and b<=beta*(l3-l1) and v<=l3-l2 and b<=l2-l1+v and \
            d<=beta*(l2-l1-b+v) and d<= (1-beta)*(l3+b-l2-v)) \
        or (b>beta*(l3-l1) and b<=l3-l1 and v<=l3-l2 and b<=l2-l1+v and \
            d<=beta*(l2-l1-b+v))):
        return "Te2"
    elif ((b<=l2-l1 and v<=l3-l2 and d>(1-beta)*(l3+b-l2-v) and b<= l2-l3+v/(1-beta)) \
        or (b<=l2-l1 and v>l3-l2 and d> (1-beta)*(b))\
        or (b>l2-l1 and b<=beta*(l3-l1) and v<=l3-l2 and b<=l2-l1+v and \
            d>(1-beta)*(l3+b-l2-v) and b<=v-beta*l1-(1-beta)*(l3)+l2)\
        or (b>l2-l1 and b<=beta*(l3-l1) and v>l3-l2 and d>(1-beta)*(b))):
        return "NTC2"
    elif (b<=l2-l1 and v<=l3-l2 and b> l2-l3+v/(1-beta) and d> beta*v):
        return "C1"
    elif ((b<=l2-l1 and v>l3-l2 and d<= (1-beta)*(b)) \
        or (b>l2-l1 and b<=beta*(l3-l1) and v>l3-l2 and d<=(1-beta)*(b)) \
        or (b>beta*(l3-l1) and b<=l3-l1 and v>l3-l2 and d<= beta*(l3-l1-b))):
        return "Te3"
    elif ((b>l2-l1 and b<=beta*(l3-l1) and v<=l3-l2 and b<=l2-l1+v and \
           d>beta*(l2-l1-b+v) and b>v-beta*l1-(1-beta)*(l3)+l2) \
        or (b>l2-l1 and b<=beta*(l3-l1) and v<=l3-l2 and b>l2-l1+v) \
        or (b>beta*(l3-l1) and b<=l3-l1 and v<=l3-l2 and b<=l2-l1+v and \
            d>beta*(l2-l1-b+v)) \
        or (b>beta*(l3-l1) and b<=l3-l1 and v<=l3-l2 and b>l2-l1+v) \
        or (b>l3-l1 and v<=l3-l2)):
        return "C2"    
    elif    ((b>beta*(l3-l1) and b<=l3-l1 and v>l3-l2 and d> beta*(l3-l1-b)) \
            or (b>l3-l1 and v>l3-l2)):
        return "NTC1"
    
# Determine the PR-regulated optimal strategies. The code is copy from d-v_under_PR.py
def color_pr(d,v):
    if ((v<=l3-l2 and b<=l2-l1) \
       or (v>l3-l2 and  b<=l2-l1 and b<=l3-l1-v and d>(1-beta)*(l2+v-l3) and \
           b<=(l3-(1-beta)*l2-v)/beta-l1) \
       or (v>l3-l2 and  b<=l2-l1 and b>l3-l1-v and b<=(l3-(1-beta)*l2-v)/beta-l1)):
        return "C1"
    elif (v<=l3-l2 and b>l2-l1):
        return "C2"
    elif (v>l3-l2 and b<=l2-l1 and b<=l3-l1-v and d<=(1-beta)*(l2+v-l3) and \
          d<=beta*(l3-l1-b-v)):
        return "Te1"
    elif ((v>l3-l2 and  b<=l2-l1 and b<=l3-l1-v and d>beta*(l3-l1-b-v)   and \
           b>(l3-(1-beta)*l2-v)/beta-l1) \
       or (v>l3-l2 and  b<=l2-l1 and b>l3-l1-v and b>(l3-(1-beta)*l2-v)/beta-l1) \
       or (v>l3-l2 and  b>l2-l1)):
        return "NTC1"
'''
4. save the unregulated and PR-regulated optimal strategies and export them to excel files

To save the files for a certain farm group, we need to make the code for all 
other farm groups inactive.
The current code is used to determine the optimal strategies for high 
productivity dairy farms.

'''
def outcome(d,v):
    return color_nopr(d,v)+color_pr(d,v)
outcome_high = []
for i,j in zip(df['d_high'][0], df['v_high'][0]):
    try:
        outcome_high.append(outcome(i,j))
    except:
        continue
df1 = pd.DataFrame(outcome_high)
df1.to_excel('outcome_high.xlsx')

'''
# For small farms
outcome_small = []
for i,j in zip(df['d_small'][0], df['v_small'][0]):
    try:
        outcome_small.append(outcome(i,j))
    except:
        continue
df1 = pd.DataFrame(outcome_small)
df1.to_excel('outcome_small.xlsx')

# For medium farms
outcome_medium = []
for i,j in zip(df['d_medium'][0], df['v_medium'][0]):
    try:
        outcome_medium.append(outcome(i,j))
    except:
        continue
df1 = pd.DataFrame(outcome_medium)
df1.to_excel('outcome_medium.xlsx')

# For large farms
outcome_large = []
for i,j in zip(df['d_large'][0], df['v_large'][0]):
    try:
        outcome_large.append(outcome(i,j))
    except:
        continue
df1 = pd.DataFrame(outcome_large)
df1.to_excel('outcome_large.xlsx')

# For Michigan farms
outcome_MI = []
for i,j in zip(df['d_MI'][0], df['v_MI'][0]):
    try:
        outcome_MI.append(outcome(i,j))
    except:
        continue
df1 = pd.DataFrame(outcome_MI)
df1.to_excel('outcome_MI.xlsx')

# For Minnesota farms
outcome_MN = []
for i,j in zip(df['d_MN'][0], df['v_MN'][0]):
    try:
        outcome_MN.append(outcome(i,j))
    except:
        continue
df1 = pd.DataFrame(outcome_MN)
df1.to_excel('outcome_MN.xlsx')

# For Wisconsin farms
outcome_WI = []
for i,j in zip(df['d_WI'][0], df['v_WI'][0]):
    try:
        outcome_WI.append(outcome(i,j))
    except:
        continue
df1 = pd.DataFrame(outcome_WI)
df1.to_excel('outcome_WI.xlsx')

# For low productivity farms
outcome_low = []
for i,j in zip(df['d_low'][0], df['v_low'][0]):
    try:
        outcome_low.append(outcome(i,j))
    except:
        continue
df1 = pd.DataFrame(outcome_low)
df1.to_excel('outcome_low.xlsx')

# For medium productivity farms
outcome_med = []
for i,j in zip(df['d_med'][0], df['v_med'][0]):
    try:
        outcome_med.append(outcome(i,j))
    except:
        continue
df1 = pd.DataFrame(outcome_med)
df1.to_excel('outcome_med.xlsx')

'''