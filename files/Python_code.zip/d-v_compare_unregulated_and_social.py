# -*- coding: utf-8 -*-
"""
Created on Tue Aug 17 11:46:40 2021

@author: Yanan Jia
"""

import numpy as np
from scipy.optimize import fsolve
import matplotlib.pyplot as plt
'''
===============================================================================
***Comparing an unregulated farmer's optimal strategies and social optimal*****
  Using Python code file 'd-v_without regulations.py', we can draw unregulated 
  farmer's optimal strategy representation in the d-v plane.
  
  Based on the same code, we can replace private antibiotic cost (parameter 'b')
  with social antibiotic cost ('b+r') to draw social optimal strategy representation, 
  where r is antibiotic resistance cost.
  To examine how an unregulated farmer's optimal strategies compare with the 
  social optimum, we draw both unregulated farmer's and social optimal strategy 
  representations in the same figure. Based on the Python code file 'd-v_without 
  regulations.py', it is very convenient to do so.  
===============================================================================
'''
# In order to plot the figure, we need to set values for other parameters.  
# In order to observe how the comparison in d-v plane between unregulated farmer's
# and social optimal strategy representaitons changes across different  
# levels of antibiotic cost, We draw figures by holding antibiotic cost fixed
# at 190, 240, 300 and 560.

beta,l1,l2,l3,b,r=0.5,0,250,600,50,300  #b=190,240,300,560

d = np.arange(0,150,0.5) 
v = np.arange(0,580,1)

fig=plt.figure(figsize=(15,7))
ax1=fig.add_subplot(111) 
'''       
   We copy the code from 'd-v_without regulations.py' to here directly.
   
   We draw lines representing indifferent conditions across which an unregulated 
   farmer's optimal strategy switch. In line artworks, the d-v plane are
   separated into several areas by solid lines. Across the areas, the corresponding 
   optimal strategy differs.      
'''
'''
================code from 'd-v_without regulations.py' ========================
'''
        
v1=l3-l2+0*d
v2=d/beta
v3=(1-beta)*(b+l3-l2)+0*d
v4=l3+b-l2-d/(1-beta)
v6=d/beta-l2+l1+b
v7=b+beta*l1+(1-beta)*(l3)-l2+0*d
d1=b*(1-beta)+0*v
d2=beta*(l3-l1-b)+0*v
in1=fsolve(lambda d: d/beta-(l3+b-l2-d/(1-beta)),0)# interaction between v2 and v4
in2=fsolve(lambda d: d/beta-l2+l1+b-(l3+b-l2-d/(1-beta)),0) #interaction between v6 and v4

if (b<l2-l1):
    ax1.plot(d[np.where(d<d1[0])],v1[np.where(d<d1[0])], 'k-', \
             label=r'$v=l_3-l_2$')
    ax1.plot(d[np.where(d<in1[0])],v2[np.where(d<in1[0])], 'k-', \
             label=r'$v=d/\beta$')
    ax1.plot(d[np.where(d>in1[0])],v3[np.where(d>in1[0])], 'k-', \
             label=r'$v=(1-\beta)*(b+l_3-l_2)$')
    ax1.plot(d[np.where((d1[0]<d)&(d<in1[0]))],v4[np.where((d1[0]<d)&(d<in1[0]))], \
             'k-', label=r'$v=l_3+b-l_2-d/(1-\beta)$')
    ax1.plot(d1[np.where(v>v1[1])],v[np.where(v>v1[1])], 'k-', \
             label=r'$d=b*(1-\beta)$')
elif (b>l2-l1 and b<beta*(l3-l1)):
    ax1.plot(d[np.where(d<d1[0])],v1[np.where(d<d1[0])], 'k-', \
             label=r'$v=l_3-l_2$')
    ax1.plot(d[np.where((d1[0]<d)&(d<in2[0]))],v4[np.where((d1[0]<d)&(d<in2[0]))], \
             'k-', label=r'$v=l_3+b-l_2-d/(1-\beta)$')
    ax1.plot(d[np.where(d<in2[0])],v6[np.where(d<in2[0])], 'k-' , \
             label=r'$v=d/\beta-l_2+l_1+b$')
    ax1.plot(d[np.where(d>in2[0])],v7[np.where(d>in2[0])], 'k-', \
             label=r'$v=b+\beta*l_1+(1-\beta)*(l_3)-l_2$')         
    ax1.plot(d1[np.where(v>v1[1])],v[np.where(v>v1[1])], 'k-', \
             label=r'$d=b*(1-\beta)$')
elif (b>beta*(l3-l1) and b<l3-l1):
    ax1.plot(d,v1, 'k-', label=r'$v=l_3-l_2$')
    ax1.plot(d[np.where(d <d2[0])],v6[np.where(d <d2[0])], 'k-' , \
             label=r'$v=d/\beta-l_2+l_1+b$')
    ax1.plot(d2[np.where(v>v1[0])],v[np.where(v>v1[0])], 'k-', \
             label=r'$d=\beta*(l_3-l_1-b)$')
elif (b>l3-l1):
    ax1.plot(d,v1, 'k-', label=r'$v=l_3-l_2$')
'''
================code for social optimum =======================================
Repeat the code above but replace parameter 'b' with 'b+r' everywhere.
To distinguish the lines for social planner from lines for unregulated farmers,
we add "social" when define these lines. 
'''
v1_social=l3-l2+0*d
v2_social=d/beta
v3_social=(1-beta)*(b+r+l3-l2)+0*d
v4_social=l3+b+r-l2-d/(1-beta)
v6_social=d/beta-l2+l1+b+r
v7_social=b+r+beta*l1+(1-beta)*(l3)-l2+0*d
d1_social=(b+r)*(1-beta)+0*v
d2_social=beta*(l3-l1-b-r)+0*v
in1_social=fsolve(lambda d: d/beta-(l3+b+r-l2-d/(1-beta)),0)# interaction between v2 and v4
in2_social=fsolve(lambda d: d/beta-l2+l1+b+r-(l3+b+r-l2-d/(1-beta)),0) #interaction between v6 and v4

if (r+b<l2-l1):
    ax1.plot(d[np.where(d<d1_social[0])],v1_social[np.where(d<d1_social[0])], \
             'k:', label=r'$v=l_3-l_2$')
    ax1.plot(d[np.where(d<in1_social[0])],v2_social[np.where(d<in1_social[0])], \
             'k:', label=r'$v=d/\beta$')
    ax1.plot(d[np.where(d>in1_social[0])],v3_social[np.where(d>in1_social[0])], \
             'k:', label=r'$v=(1-\beta)*(b+l_3-l_2)$')
    ax1.plot(d[np.where((d1_social[0]<d)&(d<in1_social[0]))], \
             v4_social[np.where((d1_social[0]<d)&(d<in1_social[0]))], \
             'k:', label=r'$v=l_3+b-l_2-d/(1-\beta)$')        
    ax1.plot(d1_social[np.where(v>v1_social[1])],v[np.where(v>v1_social[1])], \
             'k:', label=r'$d=b*(1-\beta)$')
elif (r+b>l2-l1 and r+b<beta*(l3-l1)):
    ax1.plot(d[np.where(d<d1_social[0])],v1_social[np.where(d<d1_social[0])], \
             'k:', label=r'$v=l_3-l_2$')
    ax1.plot(d[np.where((d1_social[0]<d)&(d<in2_social[0]))], \
             v4_social[np.where((d1_social[0]<d)&(d<in2_social[0]))], \
             'k:', label=r'$v=l_3+b-l_2-d/(1-\beta)$')
    ax1.plot(d[np.where(d<in2_social[0])],v6_social[np.where(d<in2_social[0])], \
             'k:' , label=r'$v=d/\beta-l_2+l_1+b$')
    ax1.plot(d[np.where(d>in2_social[0])],v7_social[np.where(d>in2_social[0])], \
             'k:', label=r'$v=b+\beta*l_1+(1-\beta)*(l_3)-l_2$')
    ax1.plot(d1_social[np.where(v>v1_social[1])],v[np.where(v>v1_social[1])], \
             'k:', label=r'$d=b*(1-\beta)$')
elif (r+b>beta*(l3-l1) and r+b<l3-l1):
    ax1.plot(d,v1_social, 'k:', label=r'$v=l_3-l_2$')
    ax1.plot(d[np.where(d <d2_social[0])],v6_social[np.where(d <d2_social[0])], \
             'k:' , label=r'$v=d/\beta-l_2+l_1+b$')
    ax1.plot(d2_social[np.where(v>v1_social[0])],v[np.where(v>v1_social[0])], 
             'k:', label=r'$d=\beta*(l_3-l_1-b)$')             
elif (r+b>l3-l1):
    ax1.plot(d,v1_social, 'k:', label=r'$v=l_3-l_2$')

'''       
    General setting for figures: the title, the axis labels, and where to 
    save these figures.                 
'''
# Horizontal axis is labeled as Test cost. Vertical axis is labeled as 
# Veterinary service cost.
plt.xlabel('Test cost d', fontsize='25')
plt.ylabel('veterinary service cost v', fontsize='25')

# Name the figure depending on cost parameters
cat="Lowb_"
if (b>l2-l1 and b<beta*(l3-l1)):
    cat="LowerMb_"
elif (b>beta*(l3-l1) and b<l3-l1):
    cat="UpperMb_"
elif (b>l3-l1):
    cat="Highb_"    
    
# set axis labels and ranges.
ax1.set_xticklabels([])
ax1.set_yticklabels([])
ax1.set_xlim(0,150)
ax1.set_ylim(0,580)

path = 'C:\\Users\\Yanan Jia\\Dropbox\\RA\\First dissertation paper\\Figure\\d-v\\'
plt.savefig(path+cat+'_d-v_unregulated_social.png',dpi = 800,bbox_inches = 'tight') 
plt.show()
