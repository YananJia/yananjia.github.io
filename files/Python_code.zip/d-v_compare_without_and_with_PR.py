# -*- coding: utf-8 -*-
"""
Created on Tue Aug 17 11:46:40 2021

@author: Yanan Jia
"""

import numpy as np
from scipy.optimize import fsolve
import matplotlib.pyplot as plt
'''
===============================================================================
*************Comparing farmer's optimal strategies with and without PR*********
  Using Python code file 'd-v_without regulations.py' and 'd-v_under_PR.py', 
  we can draw unregulated and PR-regulated farmer's optimal strategy representations 
  in the d-v plane respectively.
  
  To examine how PR changes farmer's optimal strategies, we draw both unregulated 
  and PR-regulated optimal strategy representations in the same figure. Based on
  the Python code file 'd-v_without regulations.py' and 'd-v_under_PR.py', it is
  very convenient to do so.  
===============================================================================
'''
# In order to plot the figure, we need to set values for other parameters.  
# In order to observe how the comparison in d-v plane between unregulated and 
# PR-regulated farmer's optimal strategy representaitons changes across different  
# levels of antibiotic cost, We draw figures by holding antibiotic cost fixed 
# at 50, 260, 310 and 600. 
beta,l1,l2,l3,b=0.5,0,250,600,50  #b=50,260,310,620

d = np.arange(0,240,0.5) 
v = np.arange(0,580,1)
fig=plt.figure(figsize=(15,7))
ax1=fig.add_subplot(111) 
'''       
  We copy the code from 'd-v_without regulations.py' to here directly.
  
  We draw lines representing indifferent conditions across which an unregulated 
  farmer's optimal strategy switch. In line artworks, the d-v plane are
  separated into several areas by solid lines. Across the areas, the corresponding 
  optimal strategy differs.    
  
  We copy the code from 'd-v_under_PR.py' to here directly.
  
  We draw lines representing indifferent conditions across which an PR-regulated 
  farmer's optimal strategy switch. In line artworks, the d-v plane are
  separated into several areas by dashed lines. Across the areas, the corresponding 
  optimal strategy differs.    
'''
'''
================code from 'd-v_without regulations.py' ========================
'''
v1=l3-l2+0*d
v2=d/beta
v3=(1-beta)*(b+l3-l2)+0*d
v4=l3+b-l2-d/(1-beta)
v6=d/beta-l2+l1+b
v7=b+beta*l1+(1-beta)*(l3)-l2+0*d
d1=b*(1-beta)+0*v
d2=beta*(l3-l1-b)+0*v
in1=fsolve(lambda d: d/beta-(l3+b-l2-d/(1-beta)),0)# interaction between v2 and v4
in2=fsolve(lambda d: d/beta-l2+l1+b-(l3+b-l2-d/(1-beta)),0) #interaction between v6 and v4
if (b<l2-l1):
    ax1.plot(d[np.where(d<d1[0])],v1[np.where(d<d1[0])], 'k-', \
             label=r'$v=l_3-l_2$')
    ax1.plot(d[np.where(d<in1[0])],v2[np.where(d<in1[0])], 'k-', \
             label=r'$v=d/\beta$')
    ax1.plot(d[np.where(d>in1[0])],v3[np.where(d>in1[0])], 'k-', \
             label=r'$v=(1-\beta)*(b+l_3-l_2)$')
    ax1.plot(d[np.where((d1[0]<d)&(d<in1[0]))],v4[np.where((d1[0]<d)&(d<in1[0]))], \
             'k-', label=r'$v=l_3+b-l_2-d/(1-\beta)$')
    #ax1.plot(b,v5, 'k-', label=r'$v=l_1-l_2+b$')
    #d[np.where(d <d2[0])]
    #d6 = [x for x in d if x<v2]
    #ax1.plot(d,v6, 'k-' , label=r'$v=d/\beta-l_2+l_1+b$')
    #ax1.plot(d,v7, 'k-', label=r'$v=b+\beta*l_1+(1-\beta)*(l_3)-l_2$')         
    ax1.plot(d1[np.where(v>v1[1])],v[np.where(v>v1[1])], 'k-', \
             label=r'$d=b*(1-\beta)$')
    #ax1.plot(d2,v, 'k-', label=r'$d=\beta*(l_3-l_1-b)$')
elif (b>l2-l1 and b<beta*(l3-l1)):
    ax1.plot(d[np.where(d<d1[0])],v1[np.where(d<d1[0])], 'k-', \
             label=r'$v=l_3-l_2$')
    #ax1.plot(d,v2, 'k-', label=r'$v=d/\beta$')
    #ax1.plot(d,v3, 'k-', label=r'$v=(1-\beta)*(b+l_3-l_2)$')
    ax1.plot(d[np.where((d1[0]<d)&(d<in2[0]))],v4[np.where((d1[0]<d)&(d<in2[0]))], \
             'k-', label=r'$v=l_3+b-l_2-d/(1-\beta)$')
    #ax1.plot(b,v5, 'k-', label=r'$v=l_1-l_2+b$')
    #d[np.where(d <d2[0])]
    #d6 = [x for x in d if x<v2]
    ax1.plot(d[np.where(d<in2[0])],v6[np.where(d<in2[0])], 'k-' , \
             label=r'$v=d/\beta-l_2+l_1+b$')
    ax1.plot(d[np.where(d>in2[0])],v7[np.where(d>in2[0])], 'k-', \
             label=r'$v=b+\beta*l_1+(1-\beta)*(l_3)-l_2$')         
    ax1.plot(d1[np.where(v>v1[1])],v[np.where(v>v1[1])], 'k-', \
             label=r'$d=b*(1-\beta)$')
    #ax1.plot(d2,v, 'k-', label=r'$d=\beta*(l_3-l_1-b)$')
elif (b>beta*(l3-l1) and b<l3-l1):
    ax1.plot(d,v1, 'k-', label=r'$v=l_3-l_2$')
    #ax1.plot(d,v2, 'k-', label=r'$v=d/\beta$')
    #ax1.plot(d,v3, 'k-', label=r'$v=(1-\beta)*(b+l_3-l_2)$')
    #ax1.plot(d,v4, 'k-', label=r'$v=l_3+b-l_2-d/(1-\beta)$')
    #ax1.plot(b,v5, 'k-', label=r'$v=l_1-l_2+b$')
    #d[np.where(d <d2[0])]
    #d6 = [x for x in d if x<v2]
    ax1.plot(d[np.where(d <d2[0])],v6[np.where(d <d2[0])], 'k-' , \
             label=r'$v=d/\beta-l_2+l_1+b$')
    #ax1.plot(d,v7, 'k-', label=r'$v=b+\beta*l_1+(1-\beta)*(l_3)-l_2$')
         
    #ax1.plot(d1,v, 'k-', label=r'$d=b*(1-\beta)$')
    ax1.plot(d2[np.where(v>v1[0])],v[np.where(v>v1[0])], 'k-', \
             label=r'$d=\beta*(l_3-l_1-b)$')
elif (b>l3-l1):
    ax1.plot(d,v1, 'k-', label=r'$v=l_3-l_2$')
    #ax1.plot(d,v2, 'k-', label=r'$v=d/\beta$')
    #ax1.plot(d,v3, 'k-', label=r'$v=(1-\beta)*(b+l_3-l_2)$')
    #ax1.plot(d,v4, 'k-', label=r'$v=l_3+b-l_2-d/(1-\beta)$')
    #ax1.plot(b,v5, 'k-', label=r'$v=l_1-l_2+b$')
    #d[np.where(d <d2[0])]
    #d6 = [x for x in d if x<v2]
    #ax1.plot(d,v6, 'k-' , label=r'$v=d/\beta-l_2+l_1+b$')
    #ax1.plot(d,v7, 'k-', label=r'$v=b+\beta*l_1+(1-\beta)*(l_3)-l_2$')
         
    #ax1.plot(d1,v, 'k-', label=r'$d=b*(1-\beta)$')
    #ax1.plot(d2,v, 'k-', label=r'$d=\beta*(l_3-l_1-b)$')

'''
================code from 'd-v_under_PR.py' ========================
'''
# To distinguish the lines for regulated farmers from lines for unregulated farmers,
# we add "PR" when define these lines.  
v1_PR=l3-l2+0*d
v2_PR=l3-beta*(l1+b)-(1-beta)*l2+0*d
v3_PR=l3-l1-b+0*d
v4_PR=d/(1-beta)-l2+l3
v5_PR=l3-l1-b-d/beta
in1_PR=fsolve(lambda d:d/(1-beta)-l2+l3-(l3-l1-b-d/beta),0)

if (b<l2-l1):
    ax1.plot(d[np.where(d>in1_PR[0])],v2_PR[np.where(d>in1_PR[0])], 'k--', \
             label=r'$v=l_3-\beta*(l_1+b)-(1-\beta)*l_2$')
    ax1.plot(d[np.where(d<in1_PR[0])],v4_PR[np.where(d<in1_PR[0])], 'k--', \
             label=r'$v=d/(1-\beta)-l_2+l_3$')
    ax1.plot(d[np.where(d<in1_PR[0])],v5_PR[np.where(d<in1_PR[0])], 'k--', \
             label=r'$v=l_3-l_1-b-d/\beta$')    
elif (b>l2-l1):
    ax1.plot(d,v1_PR, 'k--', label=r'$v=l_3-l_2$')
       
'''       
    (4) General setting for figures: the axis labels, and where to 
    save these figures.                 
'''
# Horizontal axis is labeled as Test cost. Vertical axis is labeled as Veterinary service cost.
plt.xlabel('Test cost d', fontsize='25')
plt.ylabel('Veterinary service cost v', fontsize='25')
# set axis labels and ranges.
ax1.set_xticklabels([])
ax1.set_yticklabels([])
ax1.set_xlim(0,240)
ax1.set_ylim(0,580)
# Name the figure depending on cost parameters
cat="Lowb_"
if (b>l2-l1 and b<beta*(l3-l1)):
    cat="LowerMb_"
elif (b>beta*(l3-l1) and b<l3-l1):
    cat="UpperMb_"
elif (b>l3-l1):
    cat="Highb_"
    
path = 'C:\\Users\\Yanan Jia\\Dropbox\\RA\\First dissertation paper\\Figure\\d-v\\'
plt.savefig(path+cat+'_d-v_unregulated_PR.png',dpi = 800,bbox_inches = 'tight') 
plt.show()
