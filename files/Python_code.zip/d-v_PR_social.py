# -*- coding: utf-8 -*-
"""
Created on Fri Aug 20 10:06:28 2021

@author: Yanan Jia
"""

import numpy as np
from scipy.optimize import fsolve
import matplotlib.pyplot as plt
'''
===============================================================================
******************Comparing farmer’s optimal strategies under PR **************
*************************with social optimal decisions*************************
  We put both the farmer’s optimal strategies under PR and socially optimal 
  strategies in the same figure so as to better illustrate how PR performs from 
  the perspective of social welfare. 
  
  Using Python code file 'd-v_compare_unregulated_and_social.py' and 'd-v_under_PR.py',
  we can draw line artworks representing PR-regulated farmer's optimal strategies
  and social optimal strategies in the d-v plane. 
  
  In addition, we use colors to represent, when compared with unregulated farmer's 
  optimal strategies, whether PR pushes private strategies toward social optimum 
  or further away from social optimum.
===============================================================================
'''
# In order to plot the figure, we need to set values for other parameters.  
# In order to observe how the comparison in the d-v plane between PR-regulated 
# farmer's and social optimal strategy changes across different levels of 
# antibiotic cost, we draw figures by holding antibiotic cost 
# fixed at 190, 240, 300, 560.
beta,l1,l2,l3,b,r=0.35,120,150,650,190,400  #b=190,240,300,560, r=400,600
d = np.arange(0,150,0.5) 
v = np.arange(0,600,1)
fig=plt.figure(figsize=(15,7))
ax1=fig.add_subplot(111) 
'''
=====code for social optimum from 'd-v_compare_unregulated_and_social.py'======
'''
v1_social=l3-l2+0*d
v2_social=d/beta
v3_social=(1-beta)*(b+r+l3-l2)+0*d
v4_social=l3+b+r-l2-d/(1-beta)
v6_social=d/beta-l2+l1+b+r
v7_social=b+r+beta*l1+(1-beta)*(l3)-l2+0*d
d1_social=(b+r)*(1-beta)+0*v
d2_social=beta*(l3-l1-b-r)+0*v
in1_social=fsolve(lambda d: d/beta-(l3+b+r-l2-d/(1-beta)),0)
# interaction between v2 and v4
in2_social=fsolve(lambda d: d/beta-l2+l1+b+r-(l3+b+r-l2-d/(1-beta)),0) 
# interaction between v6 and v4

if (r+b<l2-l1):
    ax1.plot(d[np.where(d<d1_social[0])],v1_social[np.where(d<d1_social[0])], \
             'k:', label=r'$v=l_3-l_2$')
    ax1.plot(d[np.where(d<in1_social[0])],v2_social[np.where(d<in1_social[0])], \
             'k:', label=r'$v=d/\beta$')
    ax1.plot(d[np.where(d>in1_social[0])],v3_social[np.where(d>in1_social[0])], \
             'k:', label=r'$v=(1-\beta)*(b+l_3-l_2)$')
    ax1.plot(d[np.where((d1_social[0]<d)&(d<in1_social[0]))], \
             v4_social[np.where((d1_social[0]<d)&(d<in1_social[0]))], \
             'k:', label=r'$v=l_3+b-l_2-d/(1-\beta)$')        
    ax1.plot(d1_social[np.where(v>v1_social[1])],v[np.where(v>v1_social[1])], \
             'k:', label=r'$d=b*(1-\beta)$')
elif (r+b>l2-l1 and r+b<beta*(l3-l1)):
    ax1.plot(d[np.where(d<d1_social[0])],v1_social[np.where(d<d1_social[0])], \
             'k:', label=r'$v=l_3-l_2$')
    ax1.plot(d[np.where((d1_social[0]<d)&(d<in2_social[0]))], \
             v4_social[np.where((d1_social[0]<d)&(d<in2_social[0]))], \
             'k:', label=r'$v=l_3+b-l_2-d/(1-\beta)$')
    ax1.plot(d[np.where(d<in2_social[0])],v6_social[np.where(d<in2_social[0])], \
             'k:' , label=r'$v=d/\beta-l_2+l_1+b$')
    ax1.plot(d[np.where(d>in2_social[0])],v7_social[np.where(d>in2_social[0])], \
             'k:', label=r'$v=b+\beta*l_1+(1-\beta)*(l_3)-l_2$')
    ax1.plot(d1_social[np.where(v>v1_social[1])],v[np.where(v>v1_social[1])], \
             'k:', label=r'$d=b*(1-\beta)$')
elif (r+b>beta*(l3-l1) and r+b<l3-l1):
    ax1.plot(d,v1_social, 'k:', label=r'$v=l_3-l_2$')
    ax1.plot(d[np.where(d <d2_social[0])],v6_social[np.where(d <d2_social[0])], \
             'k:' , label=r'$v=d/\beta-l_2+l_1+b$')
    ax1.plot(d2_social[np.where(v>v1_social[0])],v[np.where(v>v1_social[0])], 
             'k:', label=r'$d=\beta*(l_3-l_1-b)$')             
elif (r+b>l3-l1):
    ax1.plot(d,v1_social, 'k:', label=r'$v=l_3-l_2$')

'''
==========code for an PR-regulated farmer's from 'd-v_under_PR.py'=============
'''
# To distinguish the lines for regulated farmers from lines for unregulated farmers,
# we add "PR" when define these lines. 
v1_PR=l3-l2+0*d
v2_PR=l3-beta*(l1+b)-(1-beta)*l2+0*d
v3_PR=l3-l1-b+0*d
v4_PR=d/(1-beta)-l2+l3
v5_PR=l3-l1-b-d/beta
in1_PR=fsolve(lambda d:d/(1-beta)-l2+l3-(l3-l1-b-d/beta),0)

if (b<l2-l1):
    ax1.plot(d[np.where(d>in1_PR[0])],v2_PR[np.where(d>in1_PR[0])], 'k--', \
             label=r'$v=l_3-\beta*(l_1+b)-(1-\beta)*l_2$')
    ax1.plot(d[np.where(d<in1_PR[0])],v4_PR[np.where(d<in1_PR[0])], 'k--', \
             label=r'$v=d/(1-\beta)-l_2+l_3$')
    ax1.plot(d[np.where(d<in1_PR[0])],v5_PR[np.where(d<in1_PR[0])], 'k--', \
             label=r'$v=l_3-l_1-b-d/\beta$')    
elif (b>l2-l1):
    ax1.plot(d,v1_PR, 'k--', label=r'$v=l_3-l_2$')
'''
we use colors to represent, when compared with unregulated farmer's 
optimal strategies, whether PR pushes private strategies toward social optimum 
or further away from social optimum.

Under any cost parameters (b,d,v), we can figure out an unregulated/regulated 
farmer's or social planner's optimal strategy according to the model's prediction. 
We categorize every points in (b,d,v) spcace by their corresponding optimal 
strategies. 

Then we find out all of the cost parameter values (d,v) under which either or 
both of regulated and unregulated farmer's optimal strategies support social 
optimum. Also, we find out all of the cost parameter values (d,v) under which 
neither of regulated and unregulated farmer's optimal strategies support social 
optimum. For these different types of cost parameter values, we color them 
differently in the d-v plane. 
'''
# For any (d,v), find out an unreglated farmer's optimal strategies.
# Define function opt_nopr(d,v) as the rule to decide an unregulated farmer's 
# optimal strategy.This is copied from 'd-v_without regulation.py'                 
def opt_nopr(d,v):
    if ((b<=l2-l1 and v<=l3-l2 and d<=(1-beta)*(l3+b-l2-v) and d<=beta*v) \
        or (b>l2-l1 and b<=beta*(l3-l1) and v<=l3-l2 and b<=l2-l1+v and \
            d<=beta*(l2-l1-b+v) and d<= (1-beta)*(l3+b-l2-v)) \
        or (b>beta*(l3-l1) and b<=l3-l1 and v<=l3-l2 and b<=l2-l1+v and \
            d<=beta*(l2-l1-b+v))):
        return "Te2"
    elif ((b<=l2-l1 and v<=l3-l2 and d>(1-beta)*(l3+b-l2-v) and b<= l2-l3+v/(1-beta)) \
        or (b<=l2-l1 and v>l3-l2 and d> (1-beta)*(b))\
        or (b>l2-l1 and b<=beta*(l3-l1) and v<=l3-l2 and b<=l2-l1+v and \
            d>(1-beta)*(l3+b-l2-v) and b<=v-beta*l1-(1-beta)*(l3)+l2)\
        or (b>l2-l1 and b<=beta*(l3-l1) and v>l3-l2 and d>(1-beta)*(b))):
        return "NTC2"
    elif (b<=l2-l1 and v<=l3-l2 and b> l2-l3+v/(1-beta) and d> beta*v):
        return "C1"
    elif ((b<=l2-l1 and v>l3-l2 and d<= (1-beta)*(b)) \
        or (b>l2-l1 and b<=beta*(l3-l1) and v>l3-l2 and d<=(1-beta)*(b)) \
        or (b>beta*(l3-l1) and b<=l3-l1 and v>l3-l2 and d<= beta*(l3-l1-b))):
        return "Te3"
    elif ((b>l2-l1 and b<=beta*(l3-l1) and v<=l3-l2 and b<=l2-l1+v and \
           d>beta*(l2-l1-b+v) and b>v-beta*l1-(1-beta)*(l3)+l2) \
        or (b>l2-l1 and b<=beta*(l3-l1) and v<=l3-l2 and b>l2-l1+v) \
        or (b>beta*(l3-l1) and b<=l3-l1 and v<=l3-l2 and b<=l2-l1+v and \
            d>beta*(l2-l1-b+v)) \
        or (b>beta*(l3-l1) and b<=l3-l1 and v<=l3-l2 and b>l2-l1+v) \
        or (b>l3-l1 and v<=l3-l2)):
        return "C2"    
    elif    ((b>beta*(l3-l1) and b<=l3-l1 and v>l3-l2 and d> beta*(l3-l1-b)) \
            or (b>l3-l1 and v>l3-l2)):
        return "NTC1"
    
# For any (d,v), find out a PR-reglated farmer's optimal strategies.
# Define function opt_pr(d,v) as the rule to decide a PR-regulated farmer's optimal
# strategy.This is copied from 'd-v_under_PR.py'         
def opt_pr(d,v):
    if ((v<=l3-l2 and b<=l2-l1) \
       or (v>l3-l2 and  b<=l2-l1 and b<=l3-l1-v and d>(1-beta)*(l2+v-l3) and \
           b<=(l3-(1-beta)*l2-v)/beta-l1) \
       or (v>l3-l2 and  b<=l2-l1 and b>l3-l1-v and b<=(l3-(1-beta)*l2-v)/beta-l1)):
        return "C1"
    elif (v<=l3-l2 and b>l2-l1):
        return "C2"
    elif (v>l3-l2 and b<=l2-l1 and b<=l3-l1-v and d<=(1-beta)*(l2+v-l3) and \
          d<=beta*(l3-l1-b-v)):
        return "Te1"
    elif ((v>l3-l2 and  b<=l2-l1 and b<=l3-l1-v and d>beta*(l3-l1-b-v)   and \
           b>(l3-(1-beta)*l2-v)/beta-l1) \
       or (v>l3-l2 and  b<=l2-l1 and b>l3-l1-v and b>(l3-(1-beta)*l2-v)/beta-l1) \
       or (v>l3-l2 and  b>l2-l1)):
        return "NTC1"
    
# For any (d,v), find out the social optimal strategies.
# Define function opt_social(d,v) as the rule to decide the social optimal
# strategy. Based on the code from 'd-v_without regulation.py', we replace private 
# antibiotic cost (parameter 'b') with social antibiotic cost ('b+r')   
# where r is antibiotic resistance cost.      
def opt_social(d,v):
    if ((b+r<=l2-l1 and v<=l3-l2 and d<=(1-beta)*(l3+b+r-l2-v) and d<=beta*v) \
            or (b+r>l2-l1 and b+r<=beta*(l3-l1) and v<=l3-l2 and b+r<=l2-l1+v \
                and d<=beta*(l2-l1-b-r+v) and d<= (1-beta)*(l3+b+r-l2-v)) \
            or (b+r>beta*(l3-l1) and b+r<=l3-l1 and v<=l3-l2 and b+r<=l2-l1+v \
                and d<=beta*(l2-l1-b-r+v))):
        return "Te2"
    elif ((b+r<=l2-l1 and v<=l3-l2 and d>(1-beta)*(l3+b+r-l2-v) and \
           b+r<= l2-l3+v/(1-beta)) \
            or (b+r<=l2-l1 and v>l3-l2 and d> (1-beta)*(b+r))\
            or (b+r>l2-l1 and b+r<=beta*(l3-l1) and v<=l3-l2 and b+r<=l2-l1+v \
                and d>(1-beta)*(l3+b+r-l2-v) and b+r<=v-beta*l1-(1-beta)*(l3)+l2)\
            or (b+r>l2-l1 and b+r<=beta*(l3-l1) and v>l3-l2 and d>(1-beta)*(b+r))):
        return "NTC2"
    elif    (b+r<=l2-l1 and v<=l3-l2 and b+r> l2-l3+v/(1-beta) and d> beta*v):
        return "C1"
    elif    ((b+r<=l2-l1 and v>l3-l2 and d<= (1-beta)*(b+r)) \
            or (b+r>l2-l1 and b+r<=beta*(l3-l1) and v>l3-l2 and d<=(1-beta)*(b+r)) \
            or (b+r>beta*(l3-l1) and b+r<=l3-l1 and v>l3-l2 and \
                d<= beta*(l3-l1-b-r))):
        return "Te3"
    elif    ((b+r>l2-l1 and b+r<=beta*(l3-l1) and v<=l3-l2 and b+r<=l2-l1+v and \
              d>beta*(l2-l1-b-r+v) and b+r>v-beta*l1-(1-beta)*(l3)+l2) \
            or (b+r>l2-l1 and b+r<=beta*(l3-l1) and v<=l3-l2 and b+r>l2-l1+v) \
            or (b+r>beta*(l3-l1) and b+r<=l3-l1 and v<=l3-l2 and b+r<=l2-l1+v \
                and d>beta*(l2-l1-b-r+v)) \
            or (b+r>beta*(l3-l1) and b+r<=l3-l1 and v<=l3-l2 and b+r>l2-l1+v) \
            or (b+r>l3-l1 and v<=l3-l2)):
        return "C2"
    elif    ((b+r>beta*(l3-l1) and b+r<=l3-l1 and v>l3-l2 and d> beta*(l3-l1-b-r)) \
            or (b+r>l3-l1 and v>l3-l2)):
        return "NTC1"

# find out cost parameter values (d,v) under which both unregulated and PR-regulated
# farmer's optimal strategies realize social optimum. For these (d,v), we define
# color(d,v)="bothop".

# find out cost parameter values (d,v) under which unregulated farmer's optimal 
# strategies support social optimum. PR reduce social welfare. For these (d,v), 
# we define color(d,v)="noprop".

# find out cost parameter values (d,v) under which PR improves the farmer’s decisions
# and produces social optimum. For these (d,v), we define color(d,v)="prop"
 
# find out cost parameter values (d,v) under which neither unregulated and PR-regulated
# farmer's optimal strategies support social optimum. For these (d,v), we define
# color(d,v)="noop"

def color(d,v):
    a=opt_nopr(d,v)
    e=opt_pr(d,v)
    c=opt_social(d,v)
    if (a==c and e==c):
        return "bothop"
    if a==c and e!=c:
        return "noprop"
    if a!=c and e==c:
        return "prop"
    if a!=c and e!=c:
        return "noop"

# The following step categorize points by Function color(d,v) into 
# several areas which represent different evaluation results regarding how PR perfoms 
# from social welfare perspective.        

area1 = [[x,y] for x in d for y in v]          
area1_bothop = [a for a in area1 if color(a[0],a[1]) == "bothop"] 
area1_noprop = [a for a in area1 if color(a[0],a[1])=="noprop"]
area1_prop = [a for a in area1 if color(a[0],a[1]) == "prop"]  
area1_noop = [a for a in area1 if color(a[0],a[1]) == "noop"]  

# Color the areas differently. 
# In the area where both unregulated and PR-regulated farmer's optimal strategies 
# realize social optimum, we use lightpink.
# In the area where unregulated farmer's optimal strategies support social optimum
# and PR reduce social welfare, we use white.
# In the area where PR improves the farmer’s decisions and produces social optimum,
# we use lighgrey.
# In the area whereneither unregulated and PR-regulated farmer's optimal strategies
# support social optimum, we use darkgray.
li=['area1_bothop', 'area1_noprop', 'area1_prop', 'area1_noop']
color=['lightpink','w','lightgrey','darkgray']
lw=[3,3,3,3]
marker=['.','.','.','.']
alpha=[0.5,0.5,0.5,0.5]
adict = locals()
len(adict['area1_bothop'])
for i in range(len(li)):
    if len(adict[li[i]])>0:
        ax1.scatter ([a[0] for a in adict[li[i]]],[a[1] for a in adict[li[i]]], \
                     c=color[i],linewidths=lw[i],marker=marker[i], alpha = alpha[i])

'''       
    General setting for figures: the axis labels, and where to 
    save these figures.                 
'''
# Horizontal axis is labeled as Test cost. Vertical axis is labeled as 
# Veterinary service cost.
plt.xlabel('Self-test cost d', fontsize='25')
plt.ylabel('Veterinary service Cost v', fontsize='25')    

# set axis labels and ranges.
ax1.set_xticklabels([])
ax1.set_yticklabels([])
ax1.set_xlim(0,150)
ax1.set_ylim(0,600)
path = 'C:\\Users\\Yanan Jia\\Dropbox\\RA\\First dissertation paper\\Figure\\d-v\\'
plt.savefig(path+'_d-v_PR_social_color.png',dpi = 800,bbox_inches = 'tight') 
plt.show()
