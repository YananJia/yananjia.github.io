# -*- coding: utf-8 -*-
"""
Created on Sat Oct 26 17:13:28 2019

@author: Yanan Jia
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import fsolve

'''
===============================================================================
*************Figures for an unregulated farmer's optimal strategies************
  Based on optimal strategies solved by the model, we draw figures in several 
steps:
  (1) Under any cost parameters (b,d,v), we can figure out an unregulated farmer's 
  optimal strategy according to the model's prediction. We categorize every 
  points in (b,d,v) spcace by their corresponding optimal strategies. 
  We illustrate optimal strategies in b-v plane by holding self-test cost fixed.
  The b-v plane is devided into several areas which represent different optimal
  strategies.
  In order to observe how the representation of optimal strategies in b-v
  plane changes as self-test cost changes, we draw figures by holding
  self-test cost at different levels.
    (1-1) Define a rule which we use to categrize points (b,d,v).These are exact 
    conditions we drived from optimization problem.
===============================================================================
'''
# function color() can take several values: "Te2", "Te3", "NTC1", "NTC2", "C1", "C2".
def color(b,v):
    if ((b<=l2-l1 and v<=l3-l2 and d<=(1-beta)*(l3+b-l2-v) and d<=beta*v) \
        or (b>l2-l1 and b<=beta*(l3-l1) and v<=l3-l2 and b<=l2-l1+v and \
            d<=beta*(l2-l1-b+v) and d<= (1-beta)*(l3+b-l2-v)) \
        or (b>beta*(l3-l1) and b<=l3-l1 and v<=l3-l2 and b<=l2-l1+v and \
            d<=beta*(l2-l1-b+v))):
        return "Te2"
    elif ((b<=l2-l1 and v<=l3-l2 and d>(1-beta)*(l3+b-l2-v) and b<= l2-l3+v/(1-beta)) \
        or (b<=l2-l1 and v>l3-l2 and d> (1-beta)*(b))\
        or (b>l2-l1 and b<=beta*(l3-l1) and v<=l3-l2 and b<=l2-l1+v and \
            d>(1-beta)*(l3+b-l2-v) and b<=v-beta*l1-(1-beta)*(l3)+l2)\
        or (b>l2-l1 and b<=beta*(l3-l1) and v>l3-l2 and d>(1-beta)*(b))):
        return "NTC2"
    elif (b<=l2-l1 and v<=l3-l2 and b> l2-l3+v/(1-beta) and d> beta*v):
        return "C1"
    elif ((b<=l2-l1 and v>l3-l2 and d<= (1-beta)*(b)) \
        or (b>l2-l1 and b<=beta*(l3-l1) and v>l3-l2 and d<=(1-beta)*(b)) \
        or (b>beta*(l3-l1) and b<=l3-l1 and v>l3-l2 and d<= beta*(l3-l1-b))):
        return "Te3"
    elif ((b>l2-l1 and b<=beta*(l3-l1) and v<=l3-l2 and b<=l2-l1+v and \
           d>beta*(l2-l1-b+v) and b>v-beta*l1-(1-beta)*(l3)+l2) \
        or (b>l2-l1 and b<=beta*(l3-l1) and v<=l3-l2 and b>l2-l1+v) \
        or (b>beta*(l3-l1) and b<=l3-l1 and v<=l3-l2 and b<=l2-l1+v and \
            d>beta*(l2-l1-b+v)) \
        or (b>beta*(l3-l1) and b<=l3-l1 and v<=l3-l2 and b>l2-l1+v) \
        or (b>l3-l1 and v<=l3-l2)):
        return "C2"    
    elif    ((b>beta*(l3-l1) and b<=l3-l1 and v>l3-l2 and d> beta*(l3-l1-b)) \
            or (b>l3-l1 and v>l3-l2)):
        return "NTC1"
# Function color (b,v) never takes value of Te1. We prepare Te1 for figures for  
# a PR regulated farmer's optimal strategies.
#C1=Call; for 'E' infection treat, not treat if 'I'
#C2=Call; never treat
#NTC1=Neither call nor test; never treat 
#NTC2=Neither call nor test; always treat
#Te1=Test; for 'E' infection call and treat; for 'I' infection neither call nor treat
#Te2=Test; for 'E' infection do not call but treat; for 'I' infection call and do not treat
#Te3=Test; never call; for 'E' infection treat; for 'I' infection do not treat
        
'''
    (1-2) In theory, we consider every points in (b,d,v) space. In practice, 
    we consider points that evenly spread within the b-v plane. As long as the 
    distance between every two points are close enough, we can tell when
    the optimal strategy changes. 

    We consider the points in (0,600) range on b-axis and in (0,600) range on v-axis. 
    We choose these ranges so that we draw a comprehensive representation of optimal 
    strategy in b-v plane. 
    The distances between two points in b-axis and v-axis directions are assumed to 
    be 1 and 1.5 respectively. we picked these values since the distance is close 
    enough to present main findings. We can choose smaller distance, then it cost 
    more time to fill figures with colors.
'''        
# In order to plot the figure, we need to set values for other parameters. We 
# draw figures by holding self-test cost fixed at 70, 100, 150. 
beta,l1,l2,l3,d=0.5,50,250,600,100  #d=70,100,150

b = np.arange(0,600,1) 
v = np.arange(0,600,1.5)
'''
      (1-3) The following step categorize points by Function color(b,v) into 
      several areas which represent different optimal strategies.
'''        
area = [[x,y] for x in b for y in v] 
area_Te2 = [a for a in area if color(a[0],a[1]) == "Te2"]
area_Te3 = [a for a in area if color(a[0],a[1]) == "Te3"]
area_C1 = [a for a in area if color(a[0],a[1]) == "C1"] 
area_C2 = [a for a in area if color(a[0],a[1])=="C2"]
area_NTC1 = [a for a in area if color(a[0],a[1]) == "NTC1"] 
area_NTC2 = [a for a in area if color(a[0],a[1])=="NTC2"]
'''
    (1-4) When we draw b-v plane by holding parameter d fixed, we can colored
        points according to their categories.
'''   

# set the size of the figure
fig=plt.figure(figsize=(15,7))
ax1=fig.add_subplot(111) 
# colored each area
# Area with optimal strategy Te2 is colored lightskyblue
# Area with optimal strategy Te3 is colored darkseagreen
# Area with optimal strategy C1 is colored lightcoral
# Area with optimal strategy C2 is colored lightgray
# Area with optimal strategy NTC1 is colored brown
# Area with optimal strategy NTC2 is colored wheat
ax1.scatter([a[0] for a in area_Te2],[a[1] for a in area_Te2],c='lightskyblue', \
            linewidths=3,marker='.',alpha = 0.05)
ax1.scatter([a[0] for a in area_Te3],[a[1] for a in area_Te3],c='darkseagreen', \
            linewidths=3,marker='.',alpha = 0.05)
ax1.scatter([a[0] for a in area_C1],[a[1] for a in area_C1],c='lightcoral', \
            linewidths=3,marker='.', alpha = 0.05)
ax1.scatter([a[0] for a in area_C2],[a[1] for a in area_C2],c='lightgray', \
            linewidths=3,marker='.',alpha = 0.05)
ax1.scatter([a[0] for a in area_NTC1],[a[1] for a in area_NTC1],c='tab:brown', \
            linewidths=3,marker='.',alpha = 0.05)
ax1.scatter([a[0] for a in area_NTC2],[a[1] for a in area_NTC2],c='wheat', \
            linewidths=3,marker='.',alpha = 0.05)
'''       
    (2) In stead of using colored figures to illustrate how optimal strategies 
        varies across cost parameters, we prefer line artworks for paper submission. 
        Therefore we draw lines representing indifferent conditions across which 
        the farmer's optimal strategy switch. In line artworks, the b-v plane are
        separated into several areas by lines. Across the areas, optimal strategy
        may differ. Situations exist where two adjacent areas are corresponding 
        to the same optimal strategy. For these adjacent areas, we remove the 
        indifferent condition lines between them to keep the figure clean without 
        a loss of information.    
'''
# The indifferent conditions are solved from the maximization problem. We reorganize 
# these indifferent conditions at different levels of self-test cost.

# In some lines, we add remark "#" at the beginning so that the code is inactive.
# As we explained above, we deactive these code and so remove the corresponding 
# lines to make the figures clean but do not loss information. 
     
v1=l3-l2+0*b
v2=d/beta+0*b
v3=(1-beta)*(b+l3-l2)
v4=l3+b-l2-d/(1-beta)
v5=l1-l2+b
v6=d/beta-l2+l1+b
v7=b+beta*l1+(1-beta)*(l3)-l2
b1=(l2-l1)+0*v
b2=d/(1-beta)+0*v
b3=(beta*(l3-l1))+0*v
b4=(l3-l1)+0*v 
b5=l3-l1-d/beta+0*v

in1=fsolve(lambda b: d/beta-((1-beta)*(b+l3-l2)),0) #intersection between v2 and v3
in2=fsolve(lambda b: b+beta*l1+(1-beta)*(l3)-l2-((1-beta)*(b+l3-l2)),0) 
#intersection between v7 and v3
v_in2=(1-beta)*(in2[0]+l3-l2)

if d<beta*(1-beta)*(l3-l2):
    ax1.plot(b[np.where(b>b2[0])],v1[np.where(b>b2[0])], 'k-', \
             label=r'$v=l_3-l_2$')
    ax1.plot(b[np.where(b<b1[0])],v2[np.where(b<b1[0])], 'k-', \
             label=r'$v=d/\beta$')
    #ax1.plot(b,v3, 'k-', label=r'$v=(1-\beta)*(b+l_3-l_2)$')
    ax1.plot(b[np.where(b<b2[0])],v4[np.where(b<b2[0])], 'k-', \
             label=r'$v=l_3+b-l_2-d/(1-\beta)$')
    ax1.plot(b[np.where((b>b1[0]) & (b<b5[0]))],v6[np.where((b>b1[0]) & (b<b5[0]))], \
             'k-' , label=r'$v=d/\beta-l_2+l_1+b$')
    #ax1.plot(b,v7, 'k-', label=r'$v=b+\beta*l_1+(1-\beta)*(l_3)-l_2$')   
    ax1.plot(b1[np.where(v<v2[0])],v[np.where(v<v2[0])], 'k-', \
             label=r'$b=l_2-l_1$')
    ax1.plot(b2[np.where(v>v1[0])],v[np.where(v>v1[0])], 'k-', \
             label=r'$b=d/(1-\beta)$')
    #ax1.plot(b3,v, 'k-', label=r'$b=\beta*(l_3-l_1)$')
    #ax1.plot(b4,v, 'k-', label=r'$b=l_3-l_1$')
    ax1.plot(b5[np.where(v>v1[0])],v[np.where(v>v1[0])], 'k-', \
             label=r'$b=l_3-l_1-d/\beta$')
elif d>beta*(1-beta)*(l3-l2) and d<beta*(1-beta)*(l3-l1):
    ax1.plot(b[np.where(b>b2[0])],v1[np.where(b>b2[0])], 'k-', \
             label=r'$v=l_3-l_2$')
    ax1.plot(b[np.where((b>in1[0]) & (b<b1[0]))],v2[np.where((b>in1[0]) & (b<b1[0]))], \
             'k-', label=r'$v=d/\beta$')
    ax1.plot(b[np.where(b<in1[0])],v3[np.where(b<in1[0])], 'k-', \
             label=r'$v=(1-\beta)*(b+l_3-l_2)$')
    ax1.plot(b[np.where((b<b2[0]) & (b>in1[0]))],v4[np.where((b<b2[0]) & (b>in1[0]))], \
             'k-', label=r'$v=l_3+b-l_2-d/(1-\beta)$')
    ax1.plot(b[np.where((b>b1[0]) & (b<b5[0]))],v6[np.where((b>b1[0]) & (b<b5[0]))], \
             'k-' , label=r'$v=d/\beta-l_2+l_1+b$')
    #ax1.plot(b,v7, 'k-', label=r'$v=b+\beta*l_1+(1-\beta)*(l_3)-l_2$')    
    ax1.plot(b1[np.where(v<v2[0])],v[np.where(v<v2[0])], 'k-', \
             label=r'$b=l_2-l_1$')
    ax1.plot(b2[np.where(v>v1[0])],v[np.where(v>v1[0])], 'k-', \
             label=r'$b=d/(1-\beta)$')
    #ax1.plot(b3,v, 'k-', label=r'$b=\beta*(l_3-l_1)$')
    #ax1.plot(b4,v, 'k-', label=r'$b=l_3-l_1$')
    ax1.plot(b5[np.where(v>v1[0])],v[np.where(v>v1[0])], 'k-', \
             label=r'$b=l_3-l_1-d/\beta$')
elif d>beta*(1-beta)*(l3-l1):
    ax1.plot(b[np.where(b>b3[0])],v1[np.where(b>b3[0])], 'k-', \
             label=r'$v=l_3-l_2$')
    #ax1.plot(b,v2, 'k-', label=r'$v=d/\beta$')
    ax1.plot(b[np.where(b<b1[0])],v3[np.where(b<b1[0])], 'k-', \
             label=r'$v=(1-\beta)*(b+l_3-l_2)$')
    #ax1.plot(b,v4, 'k-', label=r'$v=l_3+b-l_2-d/(1-\beta)$')
    #ax1.plot(b,v6, 'k-' , label=r'$v=d/\beta-l_2+l_1+b$')
    ax1.plot(b[np.where((b>in2[0]) & (b<b3[0]))],v7[np.where((b>in2[0]) & (b<b3[0]))], \
             'k-', label=r'$v=b+\beta*l_1+(1-\beta)*(l_3)-l_2$')
    ax1.plot(b1[np.where(v<v_in2)],v[np.where(v<v_in2)], 'k-', \
             label=r'$b=l_2-l_1$')
    #ax1.plot(b2,v, 'k-', label=r'$b=d/(1-\beta)$')
    ax1.plot(b3[np.where(v>v1[0])],v[np.where(v>v1[0])], 'k-', \
             label=r'$b=\beta*(l_3-l_1)$')
    #ax1.plot(b4,v, 'k-', label=r'$b=l_3-l_1$')
    #ax1.plot(b5,v, 'k-', label=r'$b=l_3-l_1-d/\beta$')
'''           
    (3) According to colors, we can learn the corresponding optimal strategies 
    in each area. Then we deactive the code of coloring and so remove colors
    for submission. To deactive the code, we just need to add remark "#"
    at the beginning of line 112 through 117.                 
'''

'''       
    (4) General setting for figures: the title, the axis labels, and where to 
    save these figures.                 
'''
# Horizontal axis is labeled as Antibiotic cost. Vertical axis is labeled as 
# Veterinary service cost.
plt.xlabel('Antibiotic cost b', fontsize='25')
plt.ylabel('Veterinary service cost v', fontsize='25')

# set axis labels and ranges.
ax1.set_xticklabels([])
ax1.set_yticklabels([])
ax1.set_xlim(0,600)
ax1.set_ylim(0,600)

# Name the figure depending on cost parameters
cat="NA"
if d<beta*(1-beta)*(l3-l2):
    cat="Lowd_"
elif d>beta*(1-beta)*(l3-l2) and d<beta*(1-beta)*(l3-l1):
    cat="Mediumd_"
elif d>beta*(1-beta)*(l3-l1):
    cat="Highd_"

path = 'C:\\Users\\Yanan Jia\\Dropbox\\RA\\First dissertation paper\\Figure\\b-v\\'
plt.savefig(path+cat+'b-v.png',dpi = 800,bbox_inches = 'tight') 
plt.show()
'''
Note: We provide line artworks instead of colored figures in submitted paper.
'''