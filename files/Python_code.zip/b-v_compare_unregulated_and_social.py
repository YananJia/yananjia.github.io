# -*- coding: utf-8 -*-
"""
Created on Sat Oct 26 17:13:28 2019

@author: Yanan Jia
"""
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import fsolve

'''
===============================================================================
***Comparing an unregulated farmer's optimal strategies and social optimal*****
  Using Python code file 'b-v_without regulations.py', we can draw unregulated 
  farmer's optimal strategy representation in the b-v plane.
  
  Based on the same code, we can replace private antibiotic cost (parameter 'b')
  with social antibiotic cost ('b+r') to draw social optimal strategy representation, 
  where r is antibiotic resistance cost.
  To examine how unregulated farmer's optimal strategies compare with social optimum,
  we draw both unregulated farmer's and social optimal strategy representations 
  in the same figure. Based on the Python code file 'b-v_without regulations.py', 
  it is very convenient to do so.  
===============================================================================
'''
# In order to plot the figure, we need to set values for other parameters.  
# In order to observe how the comparison in b-v plane between unregulated farmer's
# and social optimal strategy representaitons changes across different  
# levels of self-test cost, We draw figures by holding self-test 
# cost fixed at 70, 100, and 160.

beta,l1,l2,l3,d,r=0.5,0,250,600,160,200  #d=70,100,160
b = np.arange(0,400,1) 
v = np.arange(0,450,1.5)
fig=plt.figure(figsize=(15,7))
ax1=fig.add_subplot(111) 

'''       
  We copy the code from 'b-v_without regulations.py' to here directly.
  
  We draw lines representing indifferent conditions across which an unregulated 
  farmer's optimal strategy switch. In line artworks, the b-d plane are
  separated into several areas by solid lines. Across the areas, the corresponding 
  optimal strategy differs.      
'''
'''
================code from 'b-v_without regulations.py' ========================
'''
v1=l3-l2+0*b
v2=d/beta+0*b
v3=(1-beta)*(b+l3-l2)
v4=l3+b-l2-d/(1-beta)
v5=l1-l2+b
v6=d/beta-l2+l1+b
v7=b+beta*l1+(1-beta)*(l3)-l2
b1=(l2-l1)+0*v
b2=d/(1-beta)+0*v
b3=(beta*(l3-l1))+0*v
b4=(l3-l1)+0*v 
b5=l3-l1-d/beta+0*v
in1=fsolve(lambda b: d/beta-((1-beta)*(b+l3-l2)),0) 
#intersection between v2 and v3
in2=fsolve(lambda b: b+beta*l1+(1-beta)*(l3)-l2-((1-beta)*(b+l3-l2)),0) 
#intersection between v7 and v3
v_in2=(1-beta)*(in2[0]+l3-l2)

if d<beta*(1-beta)*(l3-l2):
    ax1.plot(b[np.where(b>b2[0])],v1[np.where(b>b2[0])], 'k-', \
             label=r'$v=l_3-l_2$')
    ax1.plot(b[np.where(b<b1[0])],v2[np.where(b<b1[0])], 'k-', \
             label=r'$v=d/\beta$')
    ax1.plot(b[np.where(b<b2[0])],v4[np.where(b<b2[0])], 'k-', \
             label=r'$v=l_3+b-l_2-d/(1-\beta)$')
    ax1.plot(b[np.where((b>b1[0]) & (b<b5[0]))],v6[np.where((b>b1[0]) & (b<b5[0]))], \
             'k-' , label=r'$v=d/\beta-l_2+l_1+b$')
    ax1.plot(b1[np.where(v<v2[0])],v[np.where(v<v2[0])], 'k-', \
             label=r'$b=l_2-l_1$')
    ax1.plot(b2[np.where(v>v1[0])],v[np.where(v>v1[0])], 'k-', \
             label=r'$b=d/(1-\beta)$')
    ax1.plot(b5[np.where(v>v1[0])],v[np.where(v>v1[0])], 'k-', \
             label=r'$b=l_3-l_1-d/\beta$')
elif d>beta*(1-beta)*(l3-l2) and d<beta*(1-beta)*(l3-l1):
    ax1.plot(b[np.where(b>b2[0])],v1[np.where(b>b2[0])], 'k-', \
             label=r'$v=l_3-l_2$')
    ax1.plot(b[np.where((b>in1[0]) & (b<b1[0]))],v2[np.where((b>in1[0]) & (b<b1[0]))], \
             'k-', label=r'$v=d/\beta$')
    ax1.plot(b[np.where(b<in1[0])],v3[np.where(b<in1[0])], 'k-', \
             label=r'$v=(1-\beta)*(b+l_3-l_2)$')
    ax1.plot(b[np.where((b<b2[0]) & (b>in1[0]))],v4[np.where((b<b2[0]) & (b>in1[0]))], \
             'k-', label=r'$v=l_3+b-l_2-d/(1-\beta)$')
    ax1.plot(b[np.where((b>b1[0]) & (b<b5[0]))],v6[np.where((b>b1[0]) & (b<b5[0]))], \
             'k-' , label=r'$v=d/\beta-l_2+l_1+b$')
    ax1.plot(b1[np.where(v<v2[0])],v[np.where(v<v2[0])], 'k-', \
             label=r'$b=l_2-l_1$')
    ax1.plot(b2[np.where(v>v1[0])],v[np.where(v>v1[0])], 'k-', \
             label=r'$b=d/(1-\beta)$')
    ax1.plot(b5[np.where(v>v1[0])],v[np.where(v>v1[0])], 'k-', \
             label=r'$b=l_3-l_1-d/\beta$')
elif d>beta*(1-beta)*(l3-l1):
    ax1.plot(b[np.where(b>b3[0])],v1[np.where(b>b3[0])], 'k-', \
             label=r'$v=l_3-l_2$')
    ax1.plot(b[np.where(b<b1[0])],v3[np.where(b<b1[0])], 'k-', \
             label=r'$v=(1-\beta)*(b+l_3-l_2)$')
    ax1.plot(b[np.where((b>in2[0]) & (b<b3[0]))],v7[np.where((b>in2[0]) & (b<b3[0]))], \
             'k-', label=r'$v=b+\beta*l_1+(1-\beta)*(l_3)-l_2$')
    ax1.plot(b1[np.where(v<v_in2)],v[np.where(v<v_in2)], 'k-', \
             label=r'$b=l_2-l_1$')
    ax1.plot(b3[np.where(v>v1[0])],v[np.where(v>v1[0])], 'k-', \
             label=r'$b=\beta*(l_3-l_1)$')
'''
================code for social optimum =======================================
Repeat the code above but replace parameter 'b' with 'b+r' everywhere.
To distinguish the lines for social planner from lines for unregulated farmers,
we add "social" when define these lines. 
'''
v1_social=l3-l2+0*(b+r)
v2_social=d/beta+0*(b+r)
v3_social=(1-beta)*((b+r)+l3-l2)
v4_social=l3+(b+r)-l2-d/(1-beta)
v5_social=l1-l2+(b+r)
v6_social=d/beta-l2+l1+(b+r)
v7_social=(b+r)+beta*l1+(1-beta)*(l3)-l2
b1_social=(l2-l1)+0*v-r
b2_social=d/(1-beta)+0*v-r
b3_social=(beta*(l3-l1))+0*v-r
b4_social=(l3-l1)+0*v-r
b5_social=l3-l1-d/beta+0*v-r

in1_social=fsolve(lambda b: d/beta-((1-beta)*(b+r+l3-l2)),0) 
#intersection between v2 and v3
in2_social=fsolve(lambda b: b+r+beta*l1+(1-beta)*(l3)-l2-((1-beta)*(b+r+l3-l2)),0)
#intersection between v7 and v3
v_in2_social=(1-beta)*(in2[0]+l3-l2)

if d<beta*(1-beta)*(l3-l2):
    ax1.plot(b[np.where(b>b2_social[0])],v1_social[np.where(b>b2_social[0])], \
             'k:', label=r'$v=l_3-l_2$')
    ax1.plot(b[np.where(b<b1_social[0])],v2_social[np.where(b<b1_social[0])], \
             'k:', label=r'$v=d/\beta$')
    ax1.plot(b[np.where(b<b2_social[0])],v4_social[np.where(b<b2_social[0])], \
             'k:', label=r'$v=l_3+b-l_2-d/(1-\beta)$')
    ax1.plot(b[np.where((b>b1_social[0]) & (b<b5_social[0]))], \
             v6_social[np.where((b>b1_social[0]) & (b<b5_social[0]))], \
             'k:' , label=r'$v=d/\beta-l_2+l_1+b$')         
    ax1.plot(b1_social[np.where(v<v2_social[0])],v[np.where(v<v2_social[0])], \
             'k:', label=r'$b=l_2-l_1$')
    ax1.plot(b2_social[np.where(v>v1_social[0])],v[np.where(v>v1_social[0])], \
             'k:', label=r'$b=d/(1-\beta)$')
    ax1.plot(b5_social[np.where(v>v1_social[0])],v[np.where(v>v1_social[0])], \
             'k:', label=r'$b=l_3-l_1-d/\beta$')


elif d>beta*(1-beta)*(l3-l2) and d<beta*(1-beta)*(l3-l1):
    ax1.plot(b[np.where(b>b2_social[0])],v1_social[np.where(b>b2_social[0])], \
             'k:', label=r'$v=l_3-l_2$')
    ax1.plot(b[np.where((b>in1_social[0]) & (b<b1_social[0]))], \
             v2_social[np.where((b>in1_social[0]) & (b<b1_social[0]))], \
             'k:', label=r'$v=d/\beta$')
    ax1.plot(b[np.where(b<in1_social[0])],v3_social[np.where(b<in1_social[0])], \
             'k:', label=r'$v=(1-\beta)*(b+l_3-l_2)$')
    ax1.plot(b[np.where((b<b2_social[0]) & (b>in1_social[0]))], \
             v4_social[np.where((b<b2_social[0]) & (b>in1_social[0]))], \
             'k:', label=r'$v=l_3+b-l_2-d/(1-\beta)$')
    ax1.plot(b[np.where((b>b1_social[0]) & (b<b5_social[0]))], \
             v6_social[np.where((b>b1_social[0]) & (b<b5_social[0]))], \
             'k:' , label=r'$v=d/\beta-l_2+l_1+b$')       
    ax1.plot(b1_social[np.where(v<v2_social[0])],v[np.where(v<v2_social[0])], \
             'k:', label=r'$b=l_2-l_1$')
    ax1.plot(b2_social[np.where(v>v1_social[0])],v[np.where(v>v1_social[0])], \
             'k:', label=r'$b=d/(1-\beta)$')
    ax1.plot(b5_social[np.where(v>v1_social[0])],v[np.where(v>v1_social[0])], \
             'k:', label=r'$b=l_3-l_1-d/\beta$')
elif d>beta*(1-beta)*(l3-l1):
    ax1.plot(b[np.where(b>b3_social[0])],v1_social[np.where(b>b3_social[0])], \
             'k:', label=r'$v=l_3-l_2$')
    ax1.plot(b[np.where(b<b1_social[0])],v3_social[np.where(b<b1_social[0])], \
             'k:', label=r'$v=(1-\beta)*(b+l_3-l_2)$')
    ax1.plot(b[np.where((b>in2_social[0]) & (b<b3_social[0]))], \
             v7_social[np.where((b>in2_social[0]) & (b<b3_social[0]))], \
             'k:', label=r'$v=b+\beta*l_1+(1-\beta)*(l_3)-l_2$')         
    ax1.plot(b1_social[np.where(v<v_in2_social)],v[np.where(v<v_in2_social)], \
             'k:', label=r'$b=l_2-l_1$')
    ax1.plot(b3_social[np.where(v>v1_social[0])],v[np.where(v>v1_social[0])], \
             'k:', label=r'$b=\beta*(l_3-l_1)$')
'''       
    General setting for figures: the axis labels, and where to 
    save these figures.                 
'''
# Horizontal axis is labeled as Antibiotic cost. Vertical axis is labeled as 
# Veterinary service cost.
plt.xlabel('Antibiotic Cost b', fontsize='25')
plt.ylabel('Veterinary service Cost v', fontsize='25')
# set axis labels and ranges.
ax1.set_xticklabels([])
ax1.set_yticklabels([])
ax1.set_xlim(0,400)
ax1.set_ylim(0,450)
# Name the figure depending on cost parameters
cat="NA"
if d<beta*(1-beta)*(l3-l2):
    cat="Lowd_"
elif d>beta*(1-beta)*(l3-l2) and d<beta*(1-beta)*(l3-l1):
    cat="Mediumd_"
elif d>beta*(1-beta)*(l3-l1):
    cat="Highd_"

path = 'C:\\Users\\Yanan Jia\\Dropbox\\RA\\First dissertation paper\\Figure\\b-v\\'
plt.savefig(path+cat+'_b-v_unregulated_social.png',dpi = 800,bbox_inches = 'tight') 
plt.show()