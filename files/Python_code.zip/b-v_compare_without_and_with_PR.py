# -*- coding: utf-8 -*-
"""
Created on Sat Oct 26 17:13:28 2019

@author: Yanan Jia
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import fsolve
'''
===============================================================================
*************Comparing farmer's optimal strategies with and without PR*********
  Using Python code file 'b-v_without regulations.py' and 'b-v_under_PR.py', 
  we can draw unregulated and PR-regulated farmer's optimal strategy representations 
  in the b-v plane respectively.
  
  To examine how PR changes farmer's optimal strategies, we draw both unregulated 
  and PR-regulated optimal strategy representations in the same figure. Based on
  the Python code file 'b-v_without regulations.py' and 'b-v_under_PR.py', it is
  very convenient to do so.  
===============================================================================
'''
# In order to plot the figure, we need to set values for other parameters. We 
# In order to observe how the comparison in b-v plane between unregulated and 
# PR-regulated farmer's optimal strategy representaitons changes across different  
# levels of self-test cost, We draw figures by holding self-test cost fixed at 
# 30, 70, 100,160. 
beta,l1,l2,l3,d=0.5,0,250,600,160  #d=30,70,100,160
b = np.arange(0,650,1) 
v = np.arange(0,600,1.5)

fig=plt.figure(figsize=(15,7))
ax1=fig.add_subplot(111) 

'''       
  We copy the code from 'b-v_without regulations.py' to here directly.
  
  We draw lines representing indifferent conditions across which an unregulated 
  farmer's optimal strategy switch. In line artworks, the b-v plane are
  separated into several areas by solid lines. Across the areas, the corresponding 
  optimal strategy differs.    
  
  We copy the code from 'b-v_under_PR.py' to here directly.
  
  We draw lines representing indifferent conditions across which an PR-regulated 
  farmer's optimal strategy switch. In line artworks, the b-v plane are
  separated into several areas by dashed lines. Across the areas, the corresponding 
  optimal strategy differs.    
'''
'''
================code from 'b-v_without regulations.py' ========================
'''
v1=l3-l2+0*b
v2=d/beta+0*b
v3=(1-beta)*(b+l3-l2)
v4=l3+b-l2-d/(1-beta)
v5=l1-l2+b
v6=d/beta-l2+l1+b
v7=b+beta*l1+(1-beta)*(l3)-l2
b1=(l2-l1)+0*v
b2=d/(1-beta)+0*v
b3=(beta*(l3-l1))+0*v
b4=(l3-l1)+0*v 
b5=l3-l1-d/beta+0*v

in1=fsolve(lambda b: d/beta-((1-beta)*(b+l3-l2)),0) #intersection between v2 and v3
in2=fsolve(lambda b: b+beta*l1+(1-beta)*(l3)-l2-((1-beta)*(b+l3-l2)),0) 
#intersection between v7 and v3
v_in2=(1-beta)*(in2[0]+l3-l2)

if d<beta*(1-beta)*(l3-l2):
    ax1.plot(b[np.where(b>b2[0])],v1[np.where(b>b2[0])], 'k-', \
             label=r'$v=l_3-l_2$')
    ax1.plot(b[np.where(b<b1[0])],v2[np.where(b<b1[0])], 'k-', \
             label=r'$v=d/\beta$')
    #ax1.plot(b,v3, 'k-', label=r'$v=(1-\beta)*(b+l_3-l_2)$')
    ax1.plot(b[np.where(b<b2[0])],v4[np.where(b<b2[0])], 'k-', \
             label=r'$v=l_3+b-l_2-d/(1-\beta)$')
    ax1.plot(b[np.where((b>b1[0]) & (b<b5[0]))],v6[np.where((b>b1[0]) & (b<b5[0]))], \
             'k-' , label=r'$v=d/\beta-l_2+l_1+b$')
    #ax1.plot(b,v7, 'k-', label=r'$v=b+\beta*l_1+(1-\beta)*(l_3)-l_2$')   
    ax1.plot(b1[np.where(v<v2[0])],v[np.where(v<v2[0])], 'k-', \
             label=r'$b=l_2-l_1$')
    ax1.plot(b2[np.where(v>v1[0])],v[np.where(v>v1[0])], 'k-', \
             label=r'$b=d/(1-\beta)$')
    #ax1.plot(b3,v, 'k-', label=r'$b=\beta*(l_3-l_1)$')
    #ax1.plot(b4,v, 'k-', label=r'$b=l_3-l_1$')
    ax1.plot(b5[np.where(v>v1[0])],v[np.where(v>v1[0])], 'k-', \
             label=r'$b=l_3-l_1-d/\beta$')
elif d>beta*(1-beta)*(l3-l2) and d<beta*(1-beta)*(l3-l1):
    ax1.plot(b[np.where(b>b2[0])],v1[np.where(b>b2[0])], 'k-', \
             label=r'$v=l_3-l_2$')
    ax1.plot(b[np.where((b>in1[0]) & (b<b1[0]))],v2[np.where((b>in1[0]) & (b<b1[0]))], \
             'k-', label=r'$v=d/\beta$')
    ax1.plot(b[np.where(b<in1[0])],v3[np.where(b<in1[0])], 'k-', \
             label=r'$v=(1-\beta)*(b+l_3-l_2)$')
    ax1.plot(b[np.where((b<b2[0]) & (b>in1[0]))],v4[np.where((b<b2[0]) & (b>in1[0]))], \
             'k-', label=r'$v=l_3+b-l_2-d/(1-\beta)$')
    ax1.plot(b[np.where((b>b1[0]) & (b<b5[0]))],v6[np.where((b>b1[0]) & (b<b5[0]))], \
             'k-' , label=r'$v=d/\beta-l_2+l_1+b$')
    #ax1.plot(b,v7, 'k-', label=r'$v=b+\beta*l_1+(1-\beta)*(l_3)-l_2$')    
    ax1.plot(b1[np.where(v<v2[0])],v[np.where(v<v2[0])], 'k-', \
             label=r'$b=l_2-l_1$')
    ax1.plot(b2[np.where(v>v1[0])],v[np.where(v>v1[0])], 'k-', \
             label=r'$b=d/(1-\beta)$')
    #ax1.plot(b3,v, 'k-', label=r'$b=\beta*(l_3-l_1)$')
    #ax1.plot(b4,v, 'k-', label=r'$b=l_3-l_1$')
    ax1.plot(b5[np.where(v>v1[0])],v[np.where(v>v1[0])], 'k-', \
             label=r'$b=l_3-l_1-d/\beta$')
elif d>beta*(1-beta)*(l3-l1):
    ax1.plot(b[np.where(b>b3[0])],v1[np.where(b>b3[0])], 'k-', \
             label=r'$v=l_3-l_2$')
    #ax1.plot(b,v2, 'k-', label=r'$v=d/\beta$')
    ax1.plot(b[np.where(b<b1[0])],v3[np.where(b<b1[0])], 'k-', \
             label=r'$v=(1-\beta)*(b+l_3-l_2)$')
    #ax1.plot(b,v4, 'k-', label=r'$v=l_3+b-l_2-d/(1-\beta)$')
    #ax1.plot(b,v6, 'k-' , label=r'$v=d/\beta-l_2+l_1+b$')
    ax1.plot(b[np.where((b>in2[0]) & (b<b3[0]))],v7[np.where((b>in2[0]) & (b<b3[0]))], \
             'k-', label=r'$v=b+\beta*l_1+(1-\beta)*(l_3)-l_2$')
    ax1.plot(b1[np.where(v<v_in2)],v[np.where(v<v_in2)], 'k-', \
             label=r'$b=l_2-l_1$')
    #ax1.plot(b2,v, 'k-', label=r'$b=d/(1-\beta)$')
    ax1.plot(b3[np.where(v>v1[0])],v[np.where(v>v1[0])], 'k-', \
             label=r'$b=\beta*(l_3-l_1)$')
    #ax1.plot(b4,v, 'k-', label=r'$b=l_3-l_1$')
    #ax1.plot(b5,v, 'k-', label=r'$b=l_3-l_1-d/\beta$')         
'''
================code from 'b-v_under_PR.py' ========================
'''
# To distinguish the lines for regulated farmers from lines for unregulated farmers,
# we add "PR" when define these lines. 
v1_PR=l3-l2+0*b
v2_PR=l3-beta*(l1+b)-(1-beta)*l2
v3_PR=l3-l1-b
v4_PR=d/(1-beta)-l2+l3+0*b
v5_PR=l3-l1-b-d/beta
b1_PR=(l2-l1)+0*v
in1_PR=fsolve(lambda b: l3-beta*(l1+b)-(1-beta)*l2-(l3-l1-b-d/beta),0) 
#intersection between v2 and v5

if d<beta*(1-beta)*(l2-l1):
    ax1.plot(b[np.where(b>b1_PR[0])],v1_PR[np.where(b>b1_PR[0])], 'k--', \
             label=r'$v=l_3-l_2$')
    ax1.plot(b[np.where((b<b1_PR[0]) & (b>in1_PR[0]))], \
             v2_PR[np.where((b<b1_PR[0]) & (b>in1_PR[0]))], \
             'k-', label=r'$v=l_3-\beta*(l_1+b)-(1-\beta)*l_2$')
        #ax1.plot(b,v3, 'k-', label=r'$v=l_3-l_1-b$')
    ax1.plot(b[np.where(b<in1_PR[0])],v4_PR[np.where(b<in1_PR[0])], 'k--', \
             label=r'$v=d/(1-\beta)-l_2+l_3$')
    ax1.plot(b[np.where(b<in1_PR[0])],v5_PR[np.where(b<in1_PR[0])], 'k--', \
             label=r'$v=l_3-l_1-b-d/\beta$')
    ax1.plot(b1_PR[np.where(v<v1_PR[0])],v[np.where(v<v1_PR[0])], 'k--', \
             label=r'$b=l_2-l_1$')
elif d>beta*(1-beta)*(l2-l1):
    ax1.plot(b[np.where(b>b1_PR[0])],v1_PR[np.where(b>b1_PR[0])], 'k--', \
             label=r'$v=l_3-l_2$')
    ax1.plot(b[np.where(b<b1_PR[0])],v2_PR[np.where(b<b1_PR[0])], 'k--', \
             label=r'$v=l_3-\beta*(l_1+b)-(1-\beta)*l_2$')
        #ax1.plot(b,v3, 'k--', label=r'$v=l_3-l_1-b$')
        #ax1.plot(b,v4, 'k--', label=r'$v=d/(1-\beta)-l_2+l_3$')
        #ax1.plot(b,v5, 'k--', label=r'$v=l_3-l_1-b-d/\beta$')
    ax1.plot(b1_PR[np.where(v<v1_PR[0])],v[np.where(v<v1_PR[0])], 'k--', label=r'$b=l_2-l_1$')
'''       
    (4) General setting for figures: the axis labels, and where to 
    save these figures.                 
'''
# Horizontal axis is labeled as Antibiotic cost. Vertical axis is labeled as 
# Veterinary service cost.
plt.xlabel('Antibiotic cost b', fontsize='25')
plt.ylabel('Veterinary service Cost v', fontsize='25')

# set axis labels and ranges.
ax1.set_xticklabels([])
ax1.set_yticklabels([])
ax1.set_xlim(0,650)
ax1.set_ylim(0,600)
# Name the figure depending on cost parameters
cat="NA"
if d<beta*(1-beta)*(l2-l1):
    cat="Lowd1_"
elif d>beta*(1-beta)*(l2-l1) and d<beta*(1-beta)*(l3-l2):
    cat="Lowd_"
elif d>beta*(1-beta)*(l3-l2) and d<beta*(1-beta)*(l3-l1):
    cat="Mediumd_"
elif d>beta*(1-beta)*(l3-l1):
    cat="Highd_"

path = 'C:\\Users\\Yanan Jia\\Dropbox\\RA\\First dissertation paper\\Figure\\b-v\\'
plt.savefig(path+cat+'_b-v_unregulated_PR.png',dpi = 800,bbox_inches = 'tight') 
plt.show()