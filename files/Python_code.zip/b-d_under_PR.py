
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 16 15:10:51 2019

@author: Yanan Jia
"""
import numpy as np
import matplotlib.pyplot as plt
'''
===============================================================================
*************Figures for a PR regulated farmer's optimal strategies************
  Based on optimal strategies solved by the model, we draw figures in several 
steps:
  (1) Under any cost parameters (b,d,v), we can figure out a PR regulated farmer's 
  optimal strategy according to the model's prediction. We categorize every points 
  in (b,d,v) spcace by their corresponding optimal strategies. 
  We illustrate optimal strategies in b-d plane by holding veterinary service 
  cost fixed. The b-d plane is devided into several areas which represent 
  different optimal strategies.
  In order to observe how the representation of optimal strategies in b-d
  plane changes as veterinary service cost changes, we draw figures by holding
  veterinary service cost at different levels.
    (1-1) Define a rule which we use to categrize points (b,d,v).These are exact 
    conditions we drived from optimization problem.
===============================================================================
'''
# function color() can take several values: "Te1", "NTC1", "C1", "C2".
def color(b,d):
    if ((v<=l3-l2 and b<=l2-l1) \
       or (v>l3-l2 and  b<=l2-l1 and b<=l3-l1-v and d>(1-beta)*(l2+v-l3) and \
           b<=(l3-(1-beta)*l2-v)/beta-l1) \
       or (v>l3-l2 and  b<=l2-l1 and b>l3-l1-v and b<=(l3-(1-beta)*l2-v)/beta-l1)):
        return "C1"
    elif (v<=l3-l2 and b>l2-l1):
        return "C2"
    elif (v>l3-l2 and b<=l2-l1 and b<=l3-l1-v and d<=(1-beta)*(l2+v-l3) and \
          d<=beta*(l3-l1-b-v)):
        return "Te1"
    elif ((v>l3-l2 and  b<=l2-l1 and b<=l3-l1-v and d>beta*(l3-l1-b-v) and \
           b>(l3-(1-beta)*l2-v)/beta-l1) \
       or (v>l3-l2 and  b<=l2-l1 and b>l3-l1-v and b>(l3-(1-beta)*l2-v)/beta-l1) \
       or (v>l3-l2 and  b>l2-l1)):
        return "NTC1"
# Label values of function color(b,d)
# Function color (b,v) never takes value of Te2, Te3 and NTC2. We prepare Te2, 
# Te3 and NTC2 for figures for an unregulated farmer's optimal strategies. 
#C1=Call; for 'E' infection treat, not treat if 'I'
#C2=Call; never treat
#NTC1=Neither call nor test; never treat 
#NTC2=Neither call nor test; always treat
#Te1=Test; for 'E' infection call and treat; for 'I' infection neither call nor treat
#Te2=Test; for 'E' infection do not call but treat; for 'I' infection call and do not treat
#Te3=Test; never call; for 'E' infection treat; for 'I' infection do not treat
'''
    (1-2) In theory, we consider every points in (b,d,v) space. In practice, 
    we consider points that evenly spread within the b-d plane. As long as the 
    distance between every two points are close enough, we can tell when
    the optimal strategy changes. 

    We consider the points in (0,250) range on b-axis and in (0,70) range on d-axis. 
    We choose these ranges so that we draw a comprehensive representation of optimal 
    strategy in b-d plane. 
    The distances between two points in b-axis and d-axis directions are assumed to 
    be 1 and 0.5 respectively. we picked these values since the distance is close 
    enough to present main findings. We can choose smaller distance, then it cost 
    more time to fill figures with colors.
'''        
# In order to plot the figure, we need to set values for other parameters. We 
# draw figures by holding veterinary service cost fixed at 300, 410, 480, 600. 
beta,l1,l2,l3,v=0.5,0,250,600,480  #v=300,410,480.600
b = np.arange(0,250,1) 
d = np.arange(0,70,0.5)
'''
    (1-3) The following step categorize points by Function color(b,d) into 
    several areas which represent different optimal strategies.
'''        
area = [[x,y] for x in b for y in d] 
area_Te1 = [a for a in area if color(a[0],a[1]) == "Te1"]
area_C1 = [a for a in area if color(a[0],a[1]) == "C1"] 
area_C2 = [a for a in area if color(a[0],a[1])=="C2"]
area_NTC1 = [a for a in area if color(a[0],a[1]) == "NTC1"] 

'''
    (1-4) When we draw b-d plane by holding parameter v fixed, we can colored
        points according to their categories.
'''   
# set the size of the figure
fig=plt.figure(figsize=(15,7))
ax1=fig.add_subplot(111) 

# colored each area
# Area with optimal strategy Te1 is colored orange
# Area with optimal strategy C1 is colored lightcoral
# Area with optimal strategy C2 is colored lightgray
# Area with optimal strategy NTC1 is colored brown
ax1.scatter([a[0] for a in area_Te1],[a[1] for a in area_Te1],c='orange', \
            linewidths=3,marker='.',alpha = 0.05)
ax1.scatter([a[0] for a in area_C1],[a[1] for a in area_C1],c='lightcoral', \
            linewidths=3,marker='.', alpha = 0.05)
ax1.scatter([a[0] for a in area_C2],[a[1] for a in area_C2],c='lightgray', \
            linewidths=3,marker='.',alpha = 0.05)
ax1.scatter([a[0] for a in area_NTC1],[a[1] for a in area_NTC1],c='tab:brown', \
            linewidths=3,marker='.',alpha = 0.05)
'''       
    (2) In stead of using colored figures to illustrate how optimal strategies 
        varies across cost parameters, we prefer line artworks for paper submission. 
        Therefore we draw lines representing indifferent conditions across which 
        the farmer's optimal strategy switch. In line artworks, the b-d plane are
        separated into several areas by lines. Across the areas, optimal strategy
        may differ. Situations exist where two adjacent areas are corresponding 
        to the same optimal strategy. For these adjacent areas, we remove the 
        indifferent condition lines between them to keep the figure clean without 
        a loss of information.    
'''
# The indifferent conditions are solved from the maximization problem. We reorganize 
# these indifferent conditions at different levels of veterinary service cost.

# In some lines, we add remark "#" at the beginning so that the code is inactive.
# As we explained above, we deactive these code and so remove the corresponding 
# lines to make the figures clean but do not loss information. 

if v<l3-l2:
    b1=(l2-l1)+0*d
    b2=(l3-(1-beta)*l2-v)/beta-l1+0*d
    ax1.plot(b1,d, 'k--', label=r'$b=l_2-l_1$')
    #ax1.plot(b2,d, 'k--', label=r'$b=(l_3-(1-\beta)*l_2-v)/\beta-l_1$')
elif v>l3-l2:
    b1=(l2-l1)+0*d
    b2=l3-l1-v+0*d
    b3=(l3-(1-beta)*l2-v)/beta-l1+0*d
    d1=(1-beta)*(l2+v-l3)+b*0
    d2=beta*(l3-l1-b-v)
    if v<l3-l1*beta-(1-beta)*l2:
        ax1.plot(b3[np.where(d>d1[0])],d[np.where(d>d1[0])], 'k--', \
                 label=r'$b=(l_3-(1-\beta)*l_2-v)/\beta-l_1$')
        ax1.plot(b[np.where(b<b3[0])],d1[np.where(b<b3[0])], 'k--', \
                 label=r'$d=(1-\beta)*(l_2+v-l_3)$')
        ax1.plot(b[np.where(b>b3[0])],d2[np.where(b>b3[0])], 'k--', \
                 label=r'$d=\beta*(l_3-l_1-b-v)$')
    elif v>l3-l1*beta-(1-beta)*l2 and v<l3-l1:
        ax1.plot(b,d2, 'k--', label=r'$d=\beta*(l_3-l_1-b-v)$')
'''       
    (3) According to colors, we can learn the corresponding optimal strategies 
    in each area. Then we deactive the code of coloring and so remove colors
    for submission. To deactive the code, we just need to add remark "#"
    at the beginning of line 98 through 103.                 
'''

'''       
    (4) General setting for figures: the axis labels, and where to 
    save these figures.                 
'''
# Horizontal axis is labeled as Antibiotic cost. Vertical axis is labeled as Test cost.
plt.xlabel('Antibiotic cost b', fontsize='25')
plt.ylabel('Test cost d', fontsize='25')

# set axis labels and ranges.     
ax1.set_xticklabels([])
ax1.set_yticklabels([])
ax1.set_xlim(0,250)
ax1.set_ylim(0,70)

# Name the figure depending on cost parameters
cat="NA"
if v<l3-l2:
    cat="PR_Lowv_"
elif v>l3-l2 and v<l3-l1*beta-(1-beta)*l2:
    cat="PR_LowerMv_"
elif v>l3-l1*beta-(1-beta)*l2 and v<l3-l1:
    cat="PR_UpperMv_"
elif v>l3-l1:
    cat="PR_Highv_"
path = 'C:\\Users\\Yanan Jia\\Dropbox\\RA\\First dissertation paper\\Figure\\b-d\\'
plt.savefig(path+cat+'b-d_PR.png',dpi = 800,bbox_inches = 'tight') 
plt.show()
'''
Note: We provide line artworks instead of colored figures in submitted paper.
'''