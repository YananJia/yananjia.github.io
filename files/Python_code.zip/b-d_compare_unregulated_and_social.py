# -*- coding: utf-8 -*-
"""
Created on Sun Aug  8 21:54:20 2021

@author: Yanan Jia
"""
import numpy as np
import matplotlib.pyplot as plt
'''
===============================================================================
***Comparing an unregulated farmer's optimal strategies and social optimal*****
  Using Python code file 'b-d_without regulations.py', we can draw unregulated 
  farmer's optimal strategy representation in the b-d plane.
  
  Based on the same code, we can replace private antibiotic cost (parameter 'b')
  with social antibiotic cost ('b+r') to draw social optimal strategy representation, 
  where r is antibiotic resistance cost.
  To examine how unregulated farmer's optimal strategies compare with social optimum,
  we draw both unregulated farmer's and social optimal strategy representations 
  in the same figure. Based on the Python code file 'b-d_without regulations.py', 
  it is very convenient to do so.  
===============================================================================
'''
# In order to plot the figure, we need to set values for other parameters.  
# In order to observe how the comparison in b-d plane between unregulated farmer's
# and social optimal strategy representaitons changes across different  
# levels of veterinary service cost, We draw figures by holding veterinary service 
# cost fixed at 170, 220, 310 and 410.

beta,l1,l2,l3,v,r=0.5,0,250,600,410,180  #v=170,220,310,410

b = np.arange(0,600,1) 
d = np.arange(0,200,0.5)

fig=plt.figure(figsize=(15,7))
ax1=fig.add_subplot(111) 
'''       
  We copy the code from 'b-d_without regulations.py' to here directly.
  
  We draw lines representing indifferent conditions across which an unregulated 
  farmer's optimal strategy switch. In line artworks, the b-d plane are
  separated into several areas by solid lines. Across the areas, the corresponding 
  optimal strategy differs.      
'''
'''
================code from 'b-d_without regulations.py' ========================
'''
if v<l3-l2:
    d1=(1-beta)*(l3+b-l2-v) 
    d2=0*b+beta*v
    d3=beta*(l2-l1-b+v)

    b1=(l2-l1)+0*d
    b2=(l2-l3+v/(1-beta))+0*d
    b3=(beta*(l3-l1))+0*d
    b4=(l3-l1)+0*d 
    b5=(l2-l1+v)+0*d
    b6=(v-beta*l1-(1-beta)*(l3)+l2)+0*d   
    if v<(1-beta)*(l3-l2):
        ax1.plot(b[np.where(b<b1[0])],d2[np.where(b<b1[0])], 'k-', \
                 label=r'$d=\beta*v$')
        ax1.plot(b[np.where(b>b1[0])],d3[np.where(b>b1[0])], 'k-', \
                 label=r'$d=\beta*(l_2-l_1-b+v)$')
        ax1.plot(b1[np.where(d>d2[0])],d[np.where(d>d2[0])], 'k-', \
                 label=r'$b=l_2-l_1$')
    elif v>(1-beta)*(l3-l2) and v<(1-beta)*(l3-l1):
        ax1.plot(b[np.where(b<b2[0])],d1[np.where(b<b2[0])], 'k-', \
                 label=r'$d=(1-\beta)*(l_3+b-l_2-v)$')
        ax1.plot(b[np.where((b>b2[0]) & (b<b1[0]))],d2[np.where((b>b2[0]) & \
                 (b<b1[0]))], 'k-', label=r'$d=\beta*v$')
        ax1.plot(b[np.where(b>b1[0])],d3[np.where(b>b1[0])], 'k-', \
                 label=r'$d=\beta*(l_2-l_1-b+v)$')
        ax1.plot(b1[np.where(d>d2[0])],d[np.where(d>d2[0])], 'k-', \
                 label=r'$b=l_2-l_1$')
        ax1.plot(b2[np.where(d>d2[0])],d[np.where(d>d2[0])], 'k-', \
                 label=r'$b=l_2-l_3+v/(1-\beta)$')
    elif v>(1-beta)*(l3-l1):
        ax1.plot(b[np.where(b<b6[0])],d1[np.where(b<b6[0])], 'k-', \
                 label=r'$d=(1-\beta)*(l_3+b-l_2-v)$')
        ax1.plot(b[np.where(b>b6[0])],d3[np.where(b>b6[0])], 'k-', \
                 label=r'$d=\beta*(l_2-l_1-b+v)$')
        d_in1=(1-beta)*(l3+b6[0]-l2-v)
        ax1.plot(b6[np.where(d>d_in1)],d[np.where(d>d_in1)], 'k-', \
                 label=r'$b=v-\beta*l_1-(1-\beta)*(l_3)+l_2$')        
elif v>l3-l2:
    d1=0*b+v-(1-beta)*(l3-l2) 
    d2=(1-beta)*b    
    d4=beta*(l3-l1-b)
    b3=(beta*(l3-l1))+0*d    
    ax1.plot(b[np.where(b<b3[0])],d2[np.where(b<b3[0])], 'k-', \
             label=r'$d=(1-\beta)*b$')
    ax1.plot(b[np.where(b>b3[0])],d4[np.where(b>b3[0])], 'k-', \
             label=r'$d=\beta*(l_3-l_1-b)$') 
    d_in2=beta*(l3-l1-b3[0])
    ax1.plot(b3[np.where(d>d_in2)],d[np.where(d>d_in2)], 'k-', \
             label=r'$b=\beta*(l_3-l_1)$')
'''
================code for social optimum =======================================
Repeat the code above but replace parameter 'b' with 'b+r' everywhere.
To distinguish the lines for social planner from lines for unregulated farmers,
we add "social" when define these lines. 
'''
if v<l3-l2:
    d1_social=(1-beta)*(l3+b+r-l2-v) 
    d2_social=0*(b+r)+beta*v
    d3_social=beta*(l2-l1-b-r+v)

    b1_social=(l2-l1)+0*d-r
    b2_social=(l2-l3+v/(1-beta))+0*d-r
    b3_social=(beta*(l3-l1))+0*d-r
    b4_social=(l3-l1)+0*d-r
    b5_social=(l2-l1+v)+0*d-r
    b6_social=(v-beta*l1-(1-beta)*(l3)+l2)+0*d-r
    if v<(1-beta)*(l3-l2):
        ax1.plot(b[np.where(b<b1_social[0])],d2_social[np.where(b<b1_social[0])], \
                 'k:', label=r'$d=\beta*v$')
        ax1.plot(b[np.where(b>b1_social[0])],d3_social[np.where(b>b1_social[0])], \
                 'k:', label=r'$d=\beta*(l_2-l_1-b+v)$')
        ax1.plot(b1_social[np.where(d>d2_social[0])],d[np.where(d>d2_social[0])], \
                 'k:', label=r'$b=l_2-l_1$')
    elif v>(1-beta)*(l3-l2) and v<(1-beta)*(l3-l1):
        ax1.plot(b[np.where(b<b2_social[0])],d1_social[np.where(b<b2_social[0])], \
                 'k:', label=r'$d=(1-\beta)*(l_3+b-l_2-v)$')
        ax1.plot(b[np.where((b>b2_social[0]) & (b<b1_social[0]))], \
                 d2_social[np.where((b>b2_social[0]) & (b<b1_social[0]))], 'k-', \
                 label=r'$d=\beta*v$')
        ax1.plot(b[np.where(b>b1_social[0])],d3_social[np.where(b>b1_social[0])], \
                 'k:', label=r'$d=\beta*(l_2-l_1-b+v)$')
        ax1.plot(b1_social[np.where(d>d2_social[0])],d[np.where(d>d2_social[0])], \
                 'k:', label=r'$b=l_2-l_1$')
        ax1.plot(b2_social[np.where(d>d2_social[0])],d[np.where(d>d2_social[0])], \
                 'k:', label=r'$b=l_2-l_3+v/(1-\beta)$')
    elif v>(1-beta)*(l3-l1):
        ax1.plot(b[np.where(b<b6_social[0])],d1_social[np.where(b<b6_social[0])], \
                 'k:', label=r'$d=(1-\beta)*(l_3+b-l_2-v)$')
        ax1.plot(b[np.where(b>b6_social[0])],d3_social[np.where(b>b6_social[0])], \
                 'k:', label=r'$d=\beta*(l_2-l_1-b+v)$')
        d_in1_social=(1-beta)*(l3+b6_social[0]+r-l2-v)
        ax1.plot(b6_social[np.where(d>d_in1_social)],d[np.where(d>d_in1_social)], \
                 'k:', label=r'$b=v-\beta*l_1-(1-\beta)*(l_3)+l_2$')
elif v>l3-l2:
    d1_social=0*(b+r)+v-(1-beta)*(l3-l2) 
    d2_social=(1-beta)*(b+r)
    d4_social=beta*(l3-l1-b-r)
    b3_social=(beta*(l3-l1))+0*d-r
    ax1.plot(b[np.where(b<b3_social[0])],d2_social[np.where(b<b3_social[0])], \
             'k:', label=r'$d=(1-\beta)*b$')
    ax1.plot(b[np.where(b>b3_social[0])],d4_social[np.where(b>b3_social[0])], \
             'k:', label=r'$d=\beta*(l_3-l_1-b)$') 
    d_in2_social=beta*(l3-l1-b3_social[0]-r)
    ax1.plot(b3_social[np.where(d>d_in2_social)],d[np.where(d>d_in2_social)], \
             'k:', label=r'$b=\beta*(l_3-l_1)$')
'''       
    General setting for figures: the title, the axis labels, and where to 
    save these figures.                 
'''
# Horizontal axis is labeled as Antibiotic cost. Vertical axis is labeled as 
# Test cost.
plt.xlabel('Antibiotic cost b', fontsize='25')
plt.ylabel('Test cost d', fontsize='25')

# set axis labels and ranges.
ax1.set_xticklabels([])
ax1.set_yticklabels([])
ax1.set_xlim(0,600)
ax1.set_ylim(0,200)

# Name the figure depending on cost parameters
cat="NA"
if v<(1-beta)*(l3-l2):
    cat="Lowv_"
elif v>(1-beta)*(l3-l2) and v<(1-beta)*(l3-l1):
    cat="LowerMv_"
elif v>(1-beta)*(l3-l1) and v<l3-l2:
    cat="UpperMv_"
elif v>l3-l2:
    cat="Highv_"
path = 'C:\\Users\\Yanan Jia\\Dropbox\\RA\\First dissertation paper\\Figure\\b-d\\'
plt.savefig(path+cat+'_b-d_unregulated_social.png',dpi = 800,bbox_inches = 'tight') 
plt.show()

    