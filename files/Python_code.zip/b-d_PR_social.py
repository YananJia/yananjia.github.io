# -*- coding: utf-8 -*-
"""
Created on Fri Aug 20 07:37:19 2021

@author: Yanan Jia
"""
import numpy as np
from scipy.optimize import fsolve
import matplotlib.pyplot as plt

'''
===============================================================================
******************Comparing farmer’s optimal strategies under PR **************
*************************with social optimal decisions*************************
  We put both the farmer’s optimal strategies under PR and socially optimal 
  strategies in the same figure so as to better illustrate how PR performs from 
  the perspective of social welfare. 
  
  Using Python code file 'b-d_compare_unregulated_and_social.py' and 'b-d_under_PR.py',
  we can draw line artworks representing PR-regulated farmer's optimal strategies
  and social optimal strategies in the b-d plane. 
  
  In addition, we use colors to represent, when compared with unregulated farmer's 
  optimal strategies, whether PR pushes private strategies toward social optimum 
  or further away from social optimum.
===============================================================================
'''
# In order to plot the figure, we need to set values for other parameters.  
# In order to observe how the comparison in the b-d plane between PR-regulated 
# farmer's and social optimal strategy changes across different levels of 
# veterinary service cost, We draw figures by holding veterinary service cost 
# fixed at 170, 220, 300 and 400.
beta,l1,l2,l3,v,r=0.5,0,250,600,410,240  #v=170,220,300,400;r=240,480
b = np.arange(0,600,0.5) 
d = np.arange(0,200,1)
fig=plt.figure(figsize=(15,7))
ax1=fig.add_subplot(111) 
'''
=====code for social optimum from 'b-d_compare_unregulated_and_social.py'======
'''
if v<l3-l2:
    d1_social=(1-beta)*(l3+b+r-l2-v) 
    d2_social=0*(b+r)+beta*v
    d3_social=beta*(l2-l1-b-r+v)

    b1_social=(l2-l1)+0*d-r
    b2_social=(l2-l3+v/(1-beta))+0*d-r
    b3_social=(beta*(l3-l1))+0*d-r
    b4_social=(l3-l1)+0*d-r
    b5_social=(l2-l1+v)+0*d-r
    b6_social=(v-beta*l1-(1-beta)*(l3)+l2)+0*d-r
    if v<(1-beta)*(l3-l2):
        ax1.plot(b[np.where(b<b1_social[0])],d2_social[np.where(b<b1_social[0])], \
                 'k:', label=r'$d=\beta*v$')
        ax1.plot(b[np.where(b>b1_social[0])],d3_social[np.where(b>b1_social[0])], \
                 'k:', label=r'$d=\beta*(l_2-l_1-b+v)$')
        ax1.plot(b1_social[np.where(d>d2_social[0])],d[np.where(d>d2_social[0])], \
                 'k:', label=r'$b=l_2-l_1$')
    elif v>(1-beta)*(l3-l2) and v<(1-beta)*(l3-l1):
        ax1.plot(b[np.where(b<b2_social[0])],d1_social[np.where(b<b2_social[0])], \
                 'k:', label=r'$d=(1-\beta)*(l_3+b-l_2-v)$')
        ax1.plot(b[np.where((b>b2_social[0]) & (b<b1_social[0]))], \
                 d2_social[np.where((b>b2_social[0]) & (b<b1_social[0]))], 'k-', \
                 label=r'$d=\beta*v$')
        ax1.plot(b[np.where(b>b1_social[0])],d3_social[np.where(b>b1_social[0])], \
                 'k:', label=r'$d=\beta*(l_2-l_1-b+v)$')
        ax1.plot(b1_social[np.where(d>d2_social[0])],d[np.where(d>d2_social[0])], \
                 'k:', label=r'$b=l_2-l_1$')
        ax1.plot(b2_social[np.where(d>d2_social[0])],d[np.where(d>d2_social[0])], \
                 'k:', label=r'$b=l_2-l_3+v/(1-\beta)$')
    elif v>(1-beta)*(l3-l1):
        ax1.plot(b[np.where(b<b6_social[0])],d1_social[np.where(b<b6_social[0])], \
                 'k:', label=r'$d=(1-\beta)*(l_3+b-l_2-v)$')
        ax1.plot(b[np.where(b>b6_social[0])],d3_social[np.where(b>b6_social[0])], \
                 'k:', label=r'$d=\beta*(l_2-l_1-b+v)$')
        d_in1_social=(1-beta)*(l3+b6_social[0]+r-l2-v)
        ax1.plot(b6_social[np.where(d>d_in1_social)],d[np.where(d>d_in1_social)], \
                 'k:', label=r'$b=v-\beta*l_1-(1-\beta)*(l_3)+l_2$')
elif v>l3-l2:
    d1_social=0*(b+r)+v-(1-beta)*(l3-l2) 
    d2_social=(1-beta)*(b+r)
    d4_social=beta*(l3-l1-b-r)
    b3_social=(beta*(l3-l1))+0*d-r
    ax1.plot(b[np.where(b<b3_social[0])],d2_social[np.where(b<b3_social[0])], \
             'k:', label=r'$d=(1-\beta)*b$')
    ax1.plot(b[np.where(b>b3_social[0])],d4_social[np.where(b>b3_social[0])], \
             'k:', label=r'$d=\beta*(l_3-l_1-b)$') 
    d_in2_social=beta*(l3-l1-b3_social[0]-r)
    ax1.plot(b3_social[np.where(d>d_in2_social)],d[np.where(d>d_in2_social)], \
             'k:', label=r'$b=\beta*(l_3-l_1)$')

'''
==========code for an PR-regulated farmer's from 'b-d_under_PR.py'=============
'''
# To distinguish the lines for regulated farmers from lines for unregulated farmers,
# we add "PR" when define these lines. 
if v<l3-l2:
    b1_PR=(l2-l1)+0*d
    b2_PR=(l3-(1-beta)*l2-v)/beta-l1+0*d
    ax1.plot(b1_PR,d, 'k--', label=r'$b=l_2-l_1$')
elif v>l3-l2:
    b1_PR=(l2-l1)+0*d
    b2_PR=l3-l1-v+0*d
    b3_PR=(l3-(1-beta)*l2-v)/beta-l1+0*d
    d1_PR=(1-beta)*(l2+v-l3)+b*0
    d2_PR=beta*(l3-l1-b-v)
    if v<l3-l1*beta-(1-beta)*l2:
        ax1.plot(b3_PR[np.where(d>d1_PR[0])],d[np.where(d>d1_PR[0])], 'k--', \
                 label=r'$b=(l_3-(1-\beta)*l_2-v)/\beta-l_1$')
        ax1.plot(b[np.where(b<b3_PR[0])],d1_PR[np.where(b<b3_PR[0])], 'k--', \
                 label=r'$d=(1-\beta)*(l_2+v-l_3)$')
        ax1.plot(b[np.where(b>b3_PR[0])],d2_PR[np.where(b>b3_PR[0])], 'k--', \
                 label=r'$d=\beta*(l_3-l_1-b-v)$')
    elif v>l3-l1*beta-(1-beta)*l2 and v<l3-l1:
        ax1.plot(b,d2_PR, 'k--', label=r'$d=\beta*(l_3-l_1-b-v)$')

'''
we use colors to represent, when compared with unregulated farmer's 
optimal strategies, whether PR pushes private strategies toward social optimum 
or further away from social optimum.

Under any cost parameters (b,d,v), we can figure out an unregulated/regulated 
farmer's or social planner's optimal strategy according to the model's prediction. 
We categorize every points in (b,d,v) spcace by their corresponding optimal 
strategies. 

Then we find out all of the cost parameter values (b,d) under which either or 
both of regulated and unregulated farmer's optimal strategies support social 
optimum. Also, we find out all of the cost parameter values (b,d) under which 
neither of regulated and unregulated farmer's optimal strategies support social 
optimum. For these different types of cost parameter values, we color them 
differently in the b-d plane. 
'''
# For any (b,d), find out an unreglated farmer's optimal strategies.
# Define function opt_nopr(b,d) as the rule to decide an unregulated farmer's 
# optimal strategy.This is copied from 'b-d_without regulation.py'         
def opt_nopr(b,d):
    if ((b<=l2-l1 and v<=l3-l2 and d<=(1-beta)*(l3+b-l2-v) and d<=beta*v) \
        or (b>l2-l1 and b<=beta*(l3-l1) and v<=l3-l2 and b<=l2-l1+v and \
            d<=beta*(l2-l1-b+v) and d<= (1-beta)*(l3+b-l2-v)) \
        or (b>beta*(l3-l1) and b<=l3-l1 and v<=l3-l2 and b<=l2-l1+v and \
            d<=beta*(l2-l1-b+v))):
        return "Te2"
    elif ((b<=l2-l1 and v<=l3-l2 and d>(1-beta)*(l3+b-l2-v) and b<= l2-l3+v/(1-beta)) \
        or (b<=l2-l1 and v>l3-l2 and d> (1-beta)*(b))\
        or (b>l2-l1 and b<=beta*(l3-l1) and v<=l3-l2 and b<=l2-l1+v and \
            d>(1-beta)*(l3+b-l2-v) and b<=v-beta*l1-(1-beta)*(l3)+l2)\
        or (b>l2-l1 and b<=beta*(l3-l1) and v>l3-l2 and d>(1-beta)*(b))):
        return "NTC2"
    elif (b<=l2-l1 and v<=l3-l2 and b> l2-l3+v/(1-beta) and d> beta*v):
        return "C1"
    elif ((b<=l2-l1 and v>l3-l2 and d<= (1-beta)*(b)) \
        or (b>l2-l1 and b<=beta*(l3-l1) and v>l3-l2 and d<=(1-beta)*(b)) \
        or (b>beta*(l3-l1) and b<=l3-l1 and v>l3-l2 and d<= beta*(l3-l1-b))):
        return "Te3"
    elif ((b>l2-l1 and b<=beta*(l3-l1) and v<=l3-l2 and b<=l2-l1+v and \
           d>beta*(l2-l1-b+v) and b>v-beta*l1-(1-beta)*(l3)+l2) \
        or (b>l2-l1 and b<=beta*(l3-l1) and v<=l3-l2 and b>l2-l1+v) \
        or (b>beta*(l3-l1) and b<=l3-l1 and v<=l3-l2 and b<=l2-l1+v and \
            d>beta*(l2-l1-b+v)) \
        or (b>beta*(l3-l1) and b<=l3-l1 and v<=l3-l2 and b>l2-l1+v) \
        or (b>l3-l1 and v<=l3-l2)):
        return "C2"    
    elif    ((b>beta*(l3-l1) and b<=l3-l1 and v>l3-l2 and d> beta*(l3-l1-b)) \
            or (b>l3-l1 and v>l3-l2)):
        return "NTC1"
# For any (b,d), find out a PR-reglated farmer's optimal strategies.
# Define function opt_pr(b,d) as the rule to decide a PR-regulated farmer's optimal
# strategy.This is copied from 'b-d_under_PR.py'         
def opt_pr(b,d):
    if ((v<=l3-l2 and b<=l2-l1) \
       or (v>l3-l2 and  b<=l2-l1 and b<=l3-l1-v and d>(1-beta)*(l2+v-l3) and \
           b<=(l3-(1-beta)*l2-v)/beta-l1) \
       or (v>l3-l2 and  b<=l2-l1 and b>l3-l1-v and b<=(l3-(1-beta)*l2-v)/beta-l1)):
        return "C1"
    elif (v<=l3-l2 and b>l2-l1):
        return "C2"
    elif (v>l3-l2 and b<=l2-l1 and b<=l3-l1-v and d<=(1-beta)*(l2+v-l3) and \
          d<=beta*(l3-l1-b-v)):
        return "Te1"
    elif ((v>l3-l2 and  b<=l2-l1 and b<=l3-l1-v and d>beta*(l3-l1-b-v) and \
           b>(l3-(1-beta)*l2-v)/beta-l1) \
       or (v>l3-l2 and  b<=l2-l1 and b>l3-l1-v and b>(l3-(1-beta)*l2-v)/beta-l1) \
       or (v>l3-l2 and  b>l2-l1)):
        return "NTC1"

# For any (b,d), find out the social optimal strategies.
# Define function opt_social(b,d) as the rule to decide the social optimal
# strategy. Based on the code from 'b-d_without regulation.py', we replace private 
# antibiotic cost (parameter 'b') with social antibiotic cost ('b+r')   
# where r is antibiotic resistance cost.      
def opt_social(b,d):
    if ((b+r<=l2-l1 and v<=l3-l2 and d<=(1-beta)*(l3+b+r-l2-v) and d<=beta*v) \
            or (b+r>l2-l1 and b+r<=beta*(l3-l1) and v<=l3-l2 and b+r<=l2-l1+v and d<=beta*(l2-l1-b-r+v) and d<= (1-beta)*(l3+b+r-l2-v)) \
            or (b+r>beta*(l3-l1) and b+r<=l3-l1 and v<=l3-l2 and b+r<=l2-l1+v and d<=beta*(l2-l1-b-r+v))):
        return "Te2"
    elif ((b+r<=l2-l1 and v<=l3-l2 and d>(1-beta)*(l3+b+r-l2-v) and b+r<= l2-l3+v/(1-beta)) \
            or (b+r<=l2-l1 and v>l3-l2 and d> (1-beta)*(b+r))\
            or (b+r>l2-l1 and b+r<=beta*(l3-l1) and v<=l3-l2 and b+r<=l2-l1+v and d>(1-beta)*(l3+b+r-l2-v) and b+r<=v-beta*l1-(1-beta)*(l3)+l2)\
            or (b+r>l2-l1 and b+r<=beta*(l3-l1) and v>l3-l2 and d>(1-beta)*(b+r))):
        return "NTC2"
    elif    (b+r<=l2-l1 and v<=l3-l2 and b+r> l2-l3+v/(1-beta) and d> beta*v):
        return "C1"
    elif    ((b+r<=l2-l1 and v>l3-l2 and d<= (1-beta)*(b+r)) \
            or (b+r>l2-l1 and b+r<=beta*(l3-l1) and v>l3-l2 and d<=(1-beta)*(b+r)) \
            or (b+r>beta*(l3-l1) and b+r<=l3-l1 and v>l3-l2 and d<= beta*(l3-l1-b-r))):
        return "Te3"
    elif    ((b+r>l2-l1 and b+r<=beta*(l3-l1) and v<=l3-l2 and b+r<=l2-l1+v and d>beta*(l2-l1-b-r+v) and b+r>v-beta*l1-(1-beta)*(l3)+l2) \
            or (b+r>l2-l1 and b+r<=beta*(l3-l1) and v<=l3-l2 and b+r>l2-l1+v) \
            or (b+r>beta*(l3-l1) and b+r<=l3-l1 and v<=l3-l2 and b+r<=l2-l1+v and d>beta*(l2-l1-b-r+v)) \
            or (b+r>beta*(l3-l1) and b+r<=l3-l1 and v<=l3-l2 and b+r>l2-l1+v) \
            or (b+r>l3-l1 and v<=l3-l2)):
        return "C2" 
    elif    ((b+r>beta*(l3-l1) and b+r<=l3-l1 and v>l3-l2 and d> beta*(l3-l1-b-r)) \
            or (b+r>l3-l1 and v>l3-l2)):
        return "NTC1"
# find out cost parameter values (b,d) under which both unregulated and PR-regulated
# farmer's optimal strategies realize social optimum. For these (b,d), we define
# color(b,d)="bothop".

# find out cost parameter values (b,d) under which unregulated farmer's optimal 
# strategies support social optimum. PR reduce social welfare. For these (b,d), 
# we define color(b,d)="noprop".

# find out cost parameter values (b,d) under which PR improves the farmer’s decisions
# and produces social optimum. For these (b,d), we define color(b,d)="prop"
 

# find out cost parameter values (b,d) under which neither unregulated and PR-regulated
# farmer's optimal strategies support social optimum. For these (b,d), we define
# color(b,d)="noop"

def color(b,d):
    a=opt_nopr(b,d)
    e=opt_pr(b,d)
    c=opt_social(b,d)
    if (a==c and e==c):
        return "bothop"
    if a==c and e!=c:
        return "noprop"
    if a!=c and e==c:
        return "prop"
    if a!=c and e!=c:
        return "noop"

# The following step categorize points by Function color(b,d) into 
# several areas which represent different evaluation results regarding how PR perfoms 
# from social welfare perspective.
                 
area1 = [[x,y] for x in b for y in d]          
area1_bothop = [a for a in area1 if color(a[0],a[1]) == "bothop"] 
area1_noprop = [a for a in area1 if color(a[0],a[1])=="noprop"]
area1_prop = [a for a in area1 if color(a[0],a[1]) == "prop"]  
area1_noop = [a for a in area1 if color(a[0],a[1]) == "noop"]  

# Color the areas differently. 
# In the area where both unregulated and PR-regulated farmer's optimal strategies 
# realize social optimum, we use lightpink.
# In the area where unregulated farmer's optimal strategies support social optimum
# and PR reduce social welfare, we use white.
# In the area where PR improves the farmer’s decisions and produces social optimum,
# we use lighgrey.
# In the area whereneither unregulated and PR-regulated farmer's optimal strategies
# support social optimum, we use darkgray.

li=['area1_bothop', 'area1_noprop', 'area1_prop', 'area1_noop']
color=['lightpink','w','lightgrey','darkgray']
lw=[3,3,3,3]
marker=['.','.','.','.']
alpha=[0.5,0.5,0.5,0.5]
adict = locals()
len(adict['area1_bothop'])
for i in range(len(li)):
    if len(adict[li[i]])>0:
        ax1.scatter ([a[0] for a in adict[li[i]]],[a[1] for a in adict[li[i]]],c=color[i],linewidths=lw[i],marker=marker[i], alpha = alpha[i])

'''       
    General setting for figures: the axis labels, and where to 
    save these figures.                 
'''
# Horizontal axis is labeled as Antibiotic cost. Vertical axis is labeled as Test cost.
plt.xlabel('Antibiotic cost b', fontsize='25')
plt.ylabel('Self-test cost d', fontsize='25')

# set axis labels and ranges.
ax1.set_xticklabels([])
ax1.set_yticklabels([])
ax1.set_xlim(0,600)
ax1.set_ylim(0,200)

# Name the figure depending on cost parameters
cat="NA"
if v<(1-beta)*(l3-l2):
    cat="Lowv_"
elif v>(1-beta)*(l3-l2) and v<(1-beta)*(l3-l1):
    cat="LowerMv_"
elif v>(1-beta)*(l3-l1) and v<l3-l2:
    cat="UpperMv_"
elif v>l3-l2:
    cat="Highv_"
path = 'C:\\Users\\Yanan Jia\\Dropbox\\RA\\First dissertation paper\\Figure\\b-d\\'
plt.savefig(path+cat+'_b-d_PR_social_color.png',dpi = 800,bbox_inches = 'tight') 
plt.show()
