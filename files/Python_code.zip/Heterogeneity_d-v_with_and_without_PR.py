# -*- coding: utf-8 -*-
"""
Created on Wed Oct 25 10:11:14 2023

@author: Yanan
"""
'''
===============================================================================
*Heterogeneity when compare farmer's optimal strategies with and without PR**
  The code is nearly identical to what is in the Python file 'd-v_compare_without_and_with_PR.py', 
  What are the differences? 
  We divide farms by their characteristics into groups
  and use medians within group to set paramter values of l1,l2,l3, b, d and v.
===============================================================================
'''
import numpy as np
from scipy.optimize import fsolve
import matplotlib.pyplot as plt

'''
1. In order to draw a optimal strategy representation in d-v plane, we need to 
   set values for parameters beta,l1,l2,l3, and b.
   We list values used for different farm groups. To draw the representation of optimal strategies
   for a certain farm group, we need to make value list for all other farm groups
   inactive and so add remark "#" at the beginning of lines for all other farm groups.
    
   The current code is used for small dairy farms.
'''

beta,l1,l2,l3,b=0.35,90,150,800,28.5  #small farms
#beta,l1,l2,l3,b=0.35,95,150,820,40  #medium farms
#beta,l1,l2,l3,b=0.35,110,150,565,25  #large farms
#beta,l1,l2,l3,b=0.35,70,150,575,25 #MI state farms
#beta,l1,l2,l3,b=0.35,92.5,150,627.5, 25 #MN state farms
#beta,l1,l2,l3,b=0.35,105,150,761, 30 #WI state farms
#beta,l1,l2,l3,b=0.35,60,150,510,20 #low productivity farms
#beta,l1,l2,l3,b=0.35,107,150,791.5,30 #medium productivity farms
#beta,l1,l2,l3,b=0.35,120,150,650,30 #high productivity farms

# We reduce the range of d-axis and v-axis such that we can focus on the data point 
# we scattered in the following code.
d = np.arange(0,15,0.05) 
v = np.arange(0,50,0.1)
fig=plt.figure(figsize=(15,7))
ax1=fig.add_subplot(111) 

'''
2. Scatter the data point for each farm group where d= self-test cost median
   and v= veterinary service cost median. 
   The assumed values differ across farm groups. To draw the representation of optimal strategies
   for a certain farm group, we need to scattering code for all other farm groups
   inactive and so add remark "#" at the beginning of lines for all other farm groups.
    
   The current code is used for small dairy farms.
'''
ax1.scatter(1,40.5,c='tab:red',linewidths=20,marker=".",alpha = 1) #small farms
#ax1.scatter(10,45.5,c='tab:red',linewidths=20,marker='.',alpha = 1) #medium farms
#ax1.scatter(5,17.5,c='tab:red',linewidths=20,marker='.',alpha = 1) #large farms
#ax1.scatter(2,15.5,c='tab:red',linewidths=20,marker='.',alpha = 1) #MI state farms
#ax1.scatter(10,35.5,c='tab:red',linewidths=20,marker='.',alpha = 1) #MN state farms
#ax1.scatter(5,35.5,c='tab:red',linewidths=20,marker='.',alpha = 1) #WI state farms
#ax1.scatter(0,15.5,c='tab:red',linewidths=20,marker='.',alpha = 1) #low productivity farms
#ax1.scatter(5,35.5,c='tab:red',linewidths=20,marker='.',alpha = 1) #medium productivity farms
#ax1.scatter(6.5,25.5,c='tab:red',linewidths=20,marker='.',alpha = 1) #high productivity farms

'''
================code from 'd-v_compare_without_and_with_PR.py' ========================
3. Draw lines indicating boundary conditions across which optimal strategies switch.
'''         
# lines for unregulated farmers.
v1=l3-l2+0*d
v2=d/beta
v3=(1-beta)*(b+l3-l2)+0*d
v4=l3+b-l2-d/(1-beta)
v6=d/beta-l2+l1+b
v7=b+beta*l1+(1-beta)*(l3)-l2+0*d
d1=b*(1-beta)+0*v
d2=beta*(l3-l1-b)+0*v
in1=fsolve(lambda d: d/beta-(l3+b-l2-d/(1-beta)),0)# interaction between v2 and v4
in2=fsolve(lambda d: d/beta-l2+l1+b-(l3+b-l2-d/(1-beta)),0) #interaction between v6 and v4
if (b<l2-l1):
    ax1.plot(d[np.where(d<d1[0])],v1[np.where(d<d1[0])], 'k-', \
             label=r'$v=l_3-l_2$')
    ax1.plot(d[np.where(d<in1[0])],v2[np.where(d<in1[0])], 'k-', \
             label=r'$v=d/\beta$')
    ax1.plot(d[np.where(d>in1[0])],v3[np.where(d>in1[0])], 'k-', \
             label=r'$v=(1-\beta)*(b+l_3-l_2)$')
    ax1.plot(d[np.where((d1[0]<d)&(d<in1[0]))],v4[np.where((d1[0]<d)&(d<in1[0]))], \
             'k-', label=r'$v=l_3+b-l_2-d/(1-\beta)$')
    #ax1.plot(b,v5, 'k-', label=r'$v=l_1-l_2+b$')
    #d[np.where(d <d2[0])]
    #d6 = [x for x in d if x<v2]
    #ax1.plot(d,v6, 'k-' , label=r'$v=d/\beta-l_2+l_1+b$')
    #ax1.plot(d,v7, 'k-', label=r'$v=b+\beta*l_1+(1-\beta)*(l_3)-l_2$')         
    ax1.plot(d1[np.where(v>v1[1])],v[np.where(v>v1[1])], 'k-', \
             label=r'$d=b*(1-\beta)$')
    #ax1.plot(d2,v, 'k-', label=r'$d=\beta*(l_3-l_1-b)$')
elif (b>l2-l1 and b<beta*(l3-l1)):
    ax1.plot(d[np.where(d<d1[0])],v1[np.where(d<d1[0])], 'k-', \
             label=r'$v=l_3-l_2$')
    #ax1.plot(d,v2, 'k-', label=r'$v=d/\beta$')
    #ax1.plot(d,v3, 'k-', label=r'$v=(1-\beta)*(b+l_3-l_2)$')
    ax1.plot(d[np.where((d1[0]<d)&(d<in2[0]))],v4[np.where((d1[0]<d)&(d<in2[0]))], \
             'k-', label=r'$v=l_3+b-l_2-d/(1-\beta)$')
    #ax1.plot(b,v5, 'k-', label=r'$v=l_1-l_2+b$')
    #d[np.where(d <d2[0])]
    #d6 = [x for x in d if x<v2]
    ax1.plot(d[np.where(d<in2[0])],v6[np.where(d<in2[0])], 'k-' , \
             label=r'$v=d/\beta-l_2+l_1+b$')
    ax1.plot(d[np.where(d>in2[0])],v7[np.where(d>in2[0])], 'k-', \
             label=r'$v=b+\beta*l_1+(1-\beta)*(l_3)-l_2$')         
    ax1.plot(d1[np.where(v>v1[1])],v[np.where(v>v1[1])], 'k-', \
             label=r'$d=b*(1-\beta)$')
    #ax1.plot(d2,v, 'k-', label=r'$d=\beta*(l_3-l_1-b)$')
elif (b>beta*(l3-l1) and b<l3-l1):
    ax1.plot(d,v1, 'k-', label=r'$v=l_3-l_2$')
    #ax1.plot(d,v2, 'k-', label=r'$v=d/\beta$')
    #ax1.plot(d,v3, 'k-', label=r'$v=(1-\beta)*(b+l_3-l_2)$')
    #ax1.plot(d,v4, 'k-', label=r'$v=l_3+b-l_2-d/(1-\beta)$')
    #ax1.plot(b,v5, 'k-', label=r'$v=l_1-l_2+b$')
    #d[np.where(d <d2[0])]
    #d6 = [x for x in d if x<v2]
    ax1.plot(d[np.where(d <d2[0])],v6[np.where(d <d2[0])], 'k-' , \
             label=r'$v=d/\beta-l_2+l_1+b$')
    #ax1.plot(d,v7, 'k-', label=r'$v=b+\beta*l_1+(1-\beta)*(l_3)-l_2$')
         
    #ax1.plot(d1,v, 'k-', label=r'$d=b*(1-\beta)$')
    ax1.plot(d2[np.where(v>v1[0])],v[np.where(v>v1[0])], 'k-', \
             label=r'$d=\beta*(l_3-l_1-b)$')
elif (b>l3-l1):
    ax1.plot(d,v1, 'k-', label=r'$v=l_3-l_2$')
    #ax1.plot(d,v2, 'k-', label=r'$v=d/\beta$')
    #ax1.plot(d,v3, 'k-', label=r'$v=(1-\beta)*(b+l_3-l_2)$')
    #ax1.plot(d,v4, 'k-', label=r'$v=l_3+b-l_2-d/(1-\beta)$')
    #ax1.plot(b,v5, 'k-', label=r'$v=l_1-l_2+b$')
    #d[np.where(d <d2[0])]
    #d6 = [x for x in d if x<v2]
    #ax1.plot(d,v6, 'k-' , label=r'$v=d/\beta-l_2+l_1+b$')
    #ax1.plot(d,v7, 'k-', label=r'$v=b+\beta*l_1+(1-\beta)*(l_3)-l_2$')
         
    #ax1.plot(d1,v, 'k-', label=r'$d=b*(1-\beta)$')
    #ax1.plot(d2,v, 'k-', label=r'$d=\beta*(l_3-l_1-b)$')

# To distinguish the lines for regulated farmers from lines for unregulated farmers,
# we add "PR" when define these lines.  
v1_PR=l3-l2+0*d
v2_PR=l3-beta*(l1+b)-(1-beta)*l2+0*d
v3_PR=l3-l1-b+0*d
v4_PR=d/(1-beta)-l2+l3
v5_PR=l3-l1-b-d/beta
in1_PR=fsolve(lambda d:d/(1-beta)-l2+l3-(l3-l1-b-d/beta),0)

if (b<l2-l1):
    ax1.plot(d[np.where(d>in1_PR[0])],v2_PR[np.where(d>in1_PR[0])], 'k--', \
             label=r'$v=l_3-\beta*(l_1+b)-(1-\beta)*l_2$')
    ax1.plot(d[np.where(d<in1_PR[0])],v4_PR[np.where(d<in1_PR[0])], 'k--', \
             label=r'$v=d/(1-\beta)-l_2+l_3$')
    ax1.plot(d[np.where(d<in1_PR[0])],v5_PR[np.where(d<in1_PR[0])], 'k--', \
             label=r'$v=l_3-l_1-b-d/\beta$')    
elif (b>l2-l1):
    ax1.plot(d,v1_PR, 'k--', label=r'$v=l_3-l_2$')
       

'''       
4. General setting for figures: the axis labels. 
'''
# Horizontal axis is labeled as Test cost. Vertical axis is labeled as Veterinary service cost.    
plt.xlabel('Test cost d', fontsize='25')
plt.ylabel('Veterinary service cost v', fontsize='25')

plt.xticks(fontsize=16)
plt.yticks(fontsize=16)
ax1.set_xlim(0,15)
ax1.set_ylim(0,50)
plt.show()
