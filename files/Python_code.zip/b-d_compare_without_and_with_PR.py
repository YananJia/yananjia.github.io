
# -*- coding: utf-8 -*-
"""
Created on Thu Aug 19 11:36:58 2021

@author: Yanan Jia
"""

import numpy as np
import matplotlib.pyplot as plt

'''
===============================================================================
*************Comparing farmer's optimal strategies with and without PR*********
  Using Python code file 'b-d_without regulations.py' and 'b-d_under_PR.py', 
  we can draw both unregulated and PR-regulated farmer's optimal strategy 
  representations in the b-d plane respectively.
  
  To examine how PR changes farmer's optimal strategies, we draw both unregulated 
  and PR-regulated optimal strategy representations in the same figure. Based on
  the Python code file 'b-d_without regulations.py' and 'b-d_under_PR.py', it is
  very convenient to do so.  
===============================================================================
'''
# In order to plot the figure, we need to set values for other parameters.  
# In order to observe how the comparison in b-d plane between unregulated and 
# PR-regulated farmer's optimal strategy representaitons changes across different  
# levels of veterinary service cost, We draw figures by holding veterinary service 
# cost fixed at 170, 220, 345,410,480 and 600.

beta,l1,l2,l3,v=0.5,0,250,600,600 #v=170,220,345,410,480,600

b = np.arange(0,500,1) 
d = np.arange(0,200,0.5)

fig=plt.figure(figsize=(15,7))
ax1=fig.add_subplot(111) 

'''       
  We copy the code from 'b-d_without regulations.py' to here directly.
  
  We draw lines representing indifferent conditions across which an unregulated 
  farmer's optimal strategy switch. In line artworks, the b-d plane are
  separated into several areas by solid lines. Across the areas, the corresponding 
  optimal strategy differs.    
  
  We copy the code from 'b-d_under_PR.py' to here directly.
  
  We draw lines representing indifferent conditions across which an PR-regulated 
  farmer's optimal strategy switch. In line artworks, the b-d plane are
  separated into several areas by dashed lines. Across the areas, the corresponding 
  optimal strategy differs.    
'''
'''
================code from 'b-d_without regulations.py' ========================
'''
if v<l3-l2:
    d1=(1-beta)*(l3+b-l2-v) 
    d2=0*b+beta*v
    d3=beta*(l2-l1-b+v)

    b1=(l2-l1)+0*d
    b2=(l2-l3+v/(1-beta))+0*d
    b3=(beta*(l3-l1))+0*d
    b4=(l3-l1)+0*d 
    b5=(l2-l1+v)+0*d
    b6=(v-beta*l1-(1-beta)*(l3)+l2)+0*d   
    if v<(1-beta)*(l3-l2):
        #ax1.plot(b,d1, 'g--', label=r'$d=(1-\beta)*(l_3+b-l_2-v)$')
        ax1.plot(b[np.where(b<b1[0])],d2[np.where(b<b1[0])], 'k-', \
                 label=r'$d=\beta*v$')
        ax1.plot(b[np.where(b>b1[0])],d3[np.where(b>b1[0])], 'k-', \
                 label=r'$d=\beta*(l_2-l_1-b+v)$')
        ax1.plot(b1[np.where(d>d2[0])],d[np.where(d>d2[0])], 'k-', \
                 label=r'$b=l_2-l_1$')
        #ax1.plot(b2,d, 'k-', label=r'$b=l_2-l_3+v/(1-\beta)$')
        #ax1.plot(b3,d, 'k-', label=r'$b=\beta*(l_3-l_1)$')
        #ax1.plot(b4,d, 'k-', label=r'$b=l_3-l_1$')
        #ax1.plot(b5,d, 'k-', label=r'$b=l_2-l_1+v$')
        #ax1.plot(b6,d, 'k-', label=r'$b=v-\beta*l_1-(1-\beta)*(l_3)+l_2$')
    elif v>(1-beta)*(l3-l2) and v<(1-beta)*(l3-l1):
        ax1.plot(b[np.where(b<b2[0])],d1[np.where(b<b2[0])], 'k-', \
                 label=r'$d=(1-\beta)*(l_3+b-l_2-v)$')
        ax1.plot(b[np.where((b>b2[0]) & (b<b1[0]))],d2[np.where((b>b2[0]) & (b<b1[0]))], \
                 'k-', label=r'$d=\beta*v$')
        ax1.plot(b[np.where(b>b1[0])],d3[np.where(b>b1[0])], 'k-', \
                 label=r'$d=\beta*(l_2-l_1-b+v)$')
        ax1.plot(b1[np.where(d>d2[0])],d[np.where(d>d2[0])], 'k-', \
                 label=r'$b=l_2-l_1$')
        ax1.plot(b2[np.where(d>d2[0])],d[np.where(d>d2[0])], 'k-', \
                 label=r'$b=l_2-l_3+v/(1-\beta)$')
        #ax1.plot(b3,d, 'k-', label=r'$b=\beta*(l_3-l_1)$')
        #ax1.plot(b4,d, 'k-', label=r'$b=l_3-l_1$')
        #ax1.plot(b5,d, 'k-', label=r'$b=l_2-l_1+v$')
        #ax1.plot(b6,d, 'k-', label=r'$b=v-\beta*l_1-(1-\beta)*(l_3)+l_2$')
    elif v>(1-beta)*(l3-l1):
        ax1.plot(b[np.where(b<b6[0])],d1[np.where(b<b6[0])], 'k-', \
                 label=r'$d=(1-\beta)*(l_3+b-l_2-v)$')
        ax1.plot(b[np.where(b>b6[0])],d3[np.where(b>b6[0])], 'k-', \
                 label=r'$d=\beta*(l_2-l_1-b+v)$')
        d_in1=(1-beta)*(l3+b6[0]-l2-v)
        ax1.plot(b6[np.where(d>d_in1)],d[np.where(d>d_in1)], 'k-', \
                 label=r'$b=v-\beta*l_1-(1-\beta)*(l_3)+l_2$')        
        #ax1.plot(b,d2, 'k-', label=r'$d=\beta*v$')
        #ax1.plot(b1,d, 'k-', label=r'$b=l_2-l_1$')
        #ax1.plot(b2,d, 'k-', label=r'$b=l_2-l_3+v/(1-\beta)$')
        #ax1.plot(b3,d, 'k-', label=r'$b=\beta*(l_3-l_1)$')
        #ax1.plot(b4,d, 'k-', label=r'$b=l_3-l_1$')
        #ax1.plot(b5,d, 'k-', label=r'$b=l_2-l_1+v$')        
elif v>l3-l2:
    d1=0*b+v-(1-beta)*(l3-l2) 
    d2=(1-beta)*b    
    d4=beta*(l3-l1-b)
    #b1=(l2-l1)+0*d
    b3=(beta*(l3-l1))+0*d
    #ax1.plot(b,d1, 'k-',label=r'$d=v-(1-\beta)*(l_3-l_2)$')
    ax1.plot(b[np.where(b<b3[0])],d2[np.where(b<b3[0])], 'k-', \
             label=r'$d=(1-\beta)*b$')
    #ax1.plot(b,d3, 'k-', label=r'$d=v-\beta*(l_1+b)-(1-\beta)*(l_3)+l_2$')
    ax1.plot(b[np.where(b>b3[0])],d4[np.where(b>b3[0])], 'k-', \
             label=r'$d=\beta*(l_3-l_1-b)$') 
    #ax1.plot(b1,d, 'k-', label=r'$b=(l_2-l_1)$')
    d_in2=beta*(l3-l1-b3[0])
    ax1.plot(b3[np.where(d>d_in2)],d[np.where(d>d_in2)], 'k-', \
             label=r'$b=\beta*(l_3-l_1)$')
    #ax1.plot(b4,d, 'k-', label=r'$b=v-\beta*l_1-(1-\beta)*(l_3)+l_2$')
    #ax1.plot(b5,d, 'k-', label=r'$b=l_3-l_1$')    
'''
================code from 'b-d_under_PR.py' ========================
'''
# To distinguish the lines for regulated farmers from lines for unregulated farmers,
# we add "PR" when define these lines. 
if v<l3-l2:
    b1_PR=(l2-l1)+0*d
    b2_PR=(l3-(1-beta)*l2-v)/beta-l1+0*d
    ax1.plot(b1_PR,d, 'k--', label=r'$b=l_2-l_1$')
    #ax1.plot(b2_PR,d, 'k--', label=r'$b=(l_3-(1-\beta)*l_2-v)/\beta-l_1$')
elif v>l3-l2:
    b1_PR=(l2-l1)+0*d
    b2_PR=l3-l1-v+0*d
    b3_PR=(l3-(1-beta)*l2-v)/beta-l1+0*d
    d1_PR=(1-beta)*(l2+v-l3)+b*0
    d2_PR=beta*(l3-l1-b-v)
    if v<l3-l1*beta-(1-beta)*l2:
        ax1.plot(b3_PR[np.where(d>d1_PR[0])],d[np.where(d>d1_PR[0])], 'k--', \
                 label=r'$b=(l_3-(1-\beta)*l_2-v)/\beta-l_1$')
        ax1.plot(b[np.where(b<b3_PR[0])],d1_PR[np.where(b<b3_PR[0])], 'k--', \
                 label=r'$d=(1-\beta)*(l_2+v-l_3)$')
        ax1.plot(b[np.where(b>b3_PR[0])],d2_PR[np.where(b>b3_PR[0])], 'k--', \
                 label=r'$d=\beta*(l_3-l_1-b-v)$')
    elif v>l3-l1*beta-(1-beta)*l2 and v<l3-l1:
        ax1.plot(b,d2_PR, 'k--', label=r'$d=\beta*(l_3-l_1-b-v)$')

'''       
    (4) General setting for figures: the axis labels, and where to 
    save these figures.                 
'''
# Horizontal axis is labeled as Antibiotic cost. Vertical axis is labeled as Test cost.

plt.xlabel('Antibiotic cost b', fontsize='25')
plt.ylabel('Test cost d', fontsize='25')
    
# set axis labels and ranges.
ax1.set_xticklabels([])
ax1.set_yticklabels([])
ax1.set_xlim(0,500)
ax1.set_ylim(0,200)
# Name the figure depending on cost parameters
cat="NA"
if v<(1-beta)*(l3-l2):
    cat="Lowv_"
elif v>(1-beta)*(l3-l2) and v<(1-beta)*(l3-l1):
    cat="LowerMv_"
elif v>(1-beta)*(l3-l1) and v<l3-l2:
    cat="UpperMv_"
elif v>l3-l2 and v<l3-l1*beta-(1-beta)*l2:
    cat="Highv_"
elif v>l3-l1*beta-(1-beta)*l2 and v<l3-l1:
    cat="Highv2_"
elif v>l3-l1:
    cat="Highv3_"
path = 'C:\\Users\\Yanan Jia\\Dropbox\\RA\\First dissertation paper\\Figure\\b-d\\'
plt.savefig(path+cat+'_b-d_unregulated_PR_lines.png',dpi = 800,bbox_inches = 'tight') 
plt.show()
